import subprocess
import sys
import os

os.chdir(r'C:\Users\tangliying\lobsterai\project')

# 运行分析脚本
result = subprocess.run(
    [sys.executable, 'full_analysis.py'],
    capture_output=True,
    text=True,
    encoding='utf-8'
)

print("STDOUT:")
print(result.stdout)
print("\nSTDERR:")
print(result.stderr)
print(f"\n返回码：{result.returncode}")
