# survey.py - 生成问卷系统HTML文件

html_content = '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>问卷调研系统</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@300;400;500;700&family=Playfair+Display:wght@600;700&display=swap');
        :root {
            --primary: #2D3436;
            --accent: #00B894;
            --accent-light: #55EFC4;
            --bg: #FAFAFA;
            --card: #FFFFFF;
            --text: #2D3436;
            --text-light: #636E72;
            --border: #DFE6E9;
            --shadow: 0 4px 20px rgba(0,0,0,0.08);
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Noto Sans SC', sans-serif;
            background: var(--bg);
            color: var(--text);
            line-height: 1.6;
            min-height: 100vh;
        }
        .hero {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #667EEA 0%, #764BA2 100%);
        }
        .hero-content { text-align: center; padding: 2rem; }
        .hero h1 {
            font-family: 'Playfair Display', serif;
            font-size: 4rem;
            color: white;
            margin-bottom: 1rem;
        }
        .hero p { font-size: 1.3rem; color: rgba(255,255,255,0.9); margin-bottom: 3rem; }
        .btn-group { display: flex; gap: 1.5rem; justify-content: center; flex-wrap: wrap; }
        .btn {
            padding: 1rem 2.5rem;
            font-size: 1.1rem;
            font-weight: 500;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        .btn-primary { background: white; color: #667EEA; }
        .btn-secondary { background: transparent; color: white; border: 2px solid rgba(255,255,255,0.5); }
        .container { max-width: 800px; margin: 0 auto; padding: 3rem 1.5rem; }
        .card { background: var(--card); border-radius: 16px; padding: 2rem; margin-bottom: 1.5rem; box-shadow: var(--shadow); }
        .form-group { margin-bottom: 1.5rem; }
        .form-label { display: block; font-weight: 500; margin-bottom: 0.5rem; }
        .form-label .required { color: #E74C3C; }
        .form-input, .form-textarea {
            width: 100%;
            padding: 0.875rem 1rem;
            border: 2px solid var(--border);
            border-radius: 10px;
            font-size: 1rem;
        }
        .hidden { display: none !important; }
        .question-item { background: #F8F9FA; border-radius: 12px; padding: 1.5rem; margin-bottom: 1rem; }
        .btn-add { padding: 0.75rem 1.5rem; background: white; border: 2px dashed var(--border); border-radius: 10px; cursor: pointer; }
        .share-box { background: #F8F9FA; border-radius: 12px; padding: 1.5rem; margin-top: 1.5rem; }
        .toast {
            position: fixed; bottom: 2rem; left: 50%; transform: translateX(-50%);
            background: var(--primary); color: white; padding: 1rem 2rem;
            border-radius: 50px; z-index: 1000;
        }
    </style>
</head>
<body>
    <div id="home-page" class="hero">
        <div class="hero-content">
            <h1>问卷调研</h1>
            <p>轻松创建问卷，实时收集反馈</p>
            <div class="btn-group">
                <a href="#" class="btn btn-primary" onclick="showPage('create')">创建问卷</a>
                <a href="#" class="btn btn-secondary" onclick="showPage('fill')">填写问卷</a>
                <a href="#" class="btn btn-secondary" onclick="showPage('results')">查看结果</a>
            </div>
        </div>
    </div>

    <div id="create-page" class="hidden">
        <div class="container">
            <h2 style="text-align:center; margin-bottom: 2rem;">创建问卷</h2>
            <div class="card">
                <div class="form-group">
                    <label class="form-label">问卷标题 <span class="required">*</span></label>
                    <input type="text" class="form-input" id="survey-title" placeholder="请输入问卷标题">
                </div>
                <div class="form-group">
                    <label class="form-label">问卷说明</label>
                    <textarea class="form-textarea" id="survey-desc" placeholder="简要描述问卷目的"></textarea>
                </div>
            </div>
            <div id="questions-container"></div>
            <div style="display: flex; gap: 1rem; justify-content: center; margin: 2rem 0;">
                <button class="btn-add" onclick="addQuestion('single')">单选题</button>
                <button class="btn-add" onclick="addQuestion('multiple')">多选题</button>
                <button class="btn-add" onclick="addQuestion('text')">文本题</button>
                <button class="btn-add" onclick="addQuestion('rating')">评分题</button>
            </div>
            <div class="card">
                <button class="btn btn-primary" onclick="saveSurvey()" style="width: 100%;">保存问卷</button>
            </div>
            <div id="share-section" class="hidden share-box">
                <h3>分享问卷</h3>
                <p>将下方链接发送给他人即可填写</p>
                <div style="display: flex; gap: 0.5rem;">
                    <input type="text" id="share-url" readonly style="flex: 1; padding: 0.75rem;">
                    <button onclick="copyLink()">复制链接</button>
                </div>
            </div>
            <div style="text-align: center; margin-top: 2rem;">
                <a href="#" onclick="showPage('home')" style="color: var(--text-light);">返回首页</a>
            </div>
        </div>
    </div>

    <div id="fill-page" class="hidden">
        <div class="container">
            <h2 id="fill-title" style="text-align:center; margin-bottom: 1rem;">问卷标题</h2>
            <p id="fill-desc" style="text-align:center; color: var(--text-light); margin-bottom: 2rem;"></p>
            <div id="fill-questions"></div>
            <div class="card">
                <button class="btn btn-primary" onclick="submitResponse()" style="width: 100%;">提交问卷</button>
            </div>
            <div style="text-align: center; margin-top: 2rem;">
                <a href="#" onclick="showPage('home')" style="color: var(--text-light);">返回首页</a>
            </div>
        </div>
    </div>

    <div id="results-page" class="hidden">
        <div class="container">
            <h2 style="text-align:center; margin-bottom: 2rem;">调研结果</h2>
            <div style="display: flex; gap: 1rem; justify-content: center; margin-bottom: 2rem;">
                <button onclick="exportToCSV()">导出 CSV</button>
                <button onclick="exportToJSON()">导出 JSON</button>
                <button onclick="clearAllData()">清空数据</button>
            </div>
            <div id="results-container"></div>
            <div style="text-align: center; margin-top: 2rem;">
                <a href="#" onclick="showPage('home')" style="color: var(--text-light);">返回首页</a>
            </div>
        </div>
    </div>

    <div id="toast" class="toast hidden"></div>

    <script>
        let surveyData = null;
        let responses = [];
        
        function loadData() {
            const savedSurvey = localStorage.getItem('survey_data');
            const savedResponses = localStorage.getItem('survey_responses');
            if (savedSurvey) surveyData = JSON.parse(savedSurvey);
            if (savedResponses) responses = JSON.parse(savedResponses);
        }
        
        function saveData() {
            if (surveyData) localStorage.setItem('survey_data', JSON.stringify(surveyData));
            localStorage.setItem('survey_responses', JSON.stringify(responses));
        }
        
        function showPage(page) {
            document.querySelectorAll('[id$="-page"]').forEach(el => el.classList.add('hidden'));
            document.getElementById(page + '-page').classList.remove('hidden');
            if (page === 'fill') renderFillPage();
            else if (page === 'results') renderResults();
            window.scrollTo(0, 0);
        }
        
        function addQuestion(type, data = null) {
            const container = document.getElementById('questions-container');
            const id = data ? data.id : 'q-' + Date.now();
            const div = document.createElement('div');
            div.className = 'question-item';
            div.id = id;
            div.dataset.type = type;
            
            let typeLabel = type === 'single' ? '单选题' : type === 'multiple' ? '多选题' : type === 'text' ? '文本题' : '评分题';
            let optionsHtml = '';
            
            if (type === 'single' || type === 'multiple') {
                const inputType = type === 'single' ? 'radio' : 'checkbox';
                const opts = data?.options || ['选项1', '选项2'];
                optionsHtml = '<div id="' + id + '-opts">' + opts.map((opt, i) => 
                    '<div style="display:flex;gap:0.5rem;margin-bottom:0.5rem;">' +
                    '<input type="' + inputType + '" disabled>' +
                    '<input type="text" class="form-input opt-text" value="' + opt + '" placeholder="选项' + (i+1) + '">' +
                    '<button onclick="this.parentElement.remove()">删除</button></div>'
                ).join('') + '</div>' +
                '<button onclick="addOption(\'' + id + '\', \'' + inputType + '\')" style="margin-top:0.5rem;">+ 添加选项</button>';
            }
            
            div.innerHTML = 
                '<div style="display:flex;justify-content:space-between;margin-bottom:1rem;">' +
                '<span style="background:var(--accent);color:white;padding:0.25rem 0.75rem;border-radius:20px;">' + typeLabel + '</span>' +
                '<div><button onclick="moveQuestion(\'' + id + '\', -1)">上移</button>' +
                '<button onclick="moveQuestion(\'' + id + '\', 1)">下移</button>' +
                '<button onclick="document.getElementById(\'' + id + '\').remove()">删除</button></div></div>' +
                '<div class="form-group"><input type="text" class="form-input q-title" placeholder="请输入问题" value="' + (data?.title || '') + '"></div>' +
                '<label style="display:flex;align-items:center;gap:0.5rem;">' +
                '<input type="checkbox" class="q-required" ' + (data?.required ? 'checked' : '') + '> 必答题</label>' + optionsHtml;
            container.appendChild(div);
        }
        
        function addOption(qid, type) {
            const container = document.getElementById(qid + '-opts');
            const idx = container.children.length + 1;
            const div = document.createElement('div');
            div.style.cssText = 'display:flex;gap:0.5rem;margin-bottom:0.5rem;';
            div.innerHTML = '<input type="' + type + '" disabled>' +
                '<input type="text" class="form-input opt-text" placeholder="选项' + idx + '">' +
                '<button onclick="this.parentElement.remove()">删除</button>';
            container.appendChild(div);
        }
        
        function moveQuestion(id, dir) {
            const item = document.getElementById(id);
            const container = document.getElementById('questions-container');
            if (dir === -1 && item.previousElementSibling) {
                container.insertBefore(item, item.previousElementSibling);
            } else if (dir === 1 && item.nextElementSibling) {
                container.insertBefore(item.nextElementSibling, item);
            }
        }
        
        function saveSurvey() {
            const title = document.getElementById('survey-title').value.trim();
            if (!title) { showToast('请输入问卷标题'); return; }
            
            const questions = [];
            document.querySelectorAll('.question-item').forEach(item => {
                const qTitle = item.querySelector('.q-title').value.trim();
                if (!qTitle) return;
                const q = {
                    id: item.id,
                    type: item.dataset.type,
                    title: qTitle,
                    required: item.querySelector('.q-required').checked
                };
                if (q.type === 'single' || q.type === 'multiple') {
                    q.options = Array.from(item.querySelectorAll('.opt-text')).map(i => i.value.trim()).filter(v => v);
                }
                questions.push(q);
            });
            
            if (questions.length === 0) { showToast('请至少添加一个问题'); return; }
            
            surveyData = {
                title: title,
                description: document.getElementById('survey-desc').value.trim(),
                questions: questions,
                createdAt: new Date().toISOString()
            };
            saveData();
            showToast('问卷保存成功！');
            document.getElementById('share-section').classList.remove('hidden');
            document.getElementById('share-url').value = window.location.href.split('#')[0] + '#fill';
        }
        
        function copyLink() {
            document.getElementById('share-url').select();
            document.execCommand('copy');
            showToast('链接已复制！');
        }
        
        function renderFillPage() {
            const container = document.getElementById('fill-questions');
            if (!surveyData) {
                container.innerHTML = '<div class="card"><p style="text-align:center;">暂无问卷，请先<a href="#" onclick="showPage(\'create\')">创建问卷</a></p></div>';
                return;
            }
            document.getElementById('fill-title').textContent = surveyData.title;
            document.getElementById('fill-desc').textContent = surveyData.description || '';
            container.innerHTML = '';
            
            surveyData.questions.forEach((q, idx) => {
                const card = document.createElement('div');
                card.className = 'card';
                let inputHtml = '';
                
                if (q.type === 'single') {
                    inputHtml = q.options.map(opt => 
                        '<label style="display:flex;align-items:center;gap:0.5rem;padding:0.5rem;">' +
                        '<input type="radio" name="' + q.id + '" value="' + opt + '">' +
                        '<span>' + opt + '</span></label>'
                    ).join('');
                } else if (q.type === 'multiple') {
                    inputHtml = q.options.map(opt => 
                        '<label style="display:flex;align-items:center;gap:0.5rem;padding:0.5rem;">' +
                        '<input type="checkbox" name="' + q.id + '" value="' + opt + '">' +
                        '<span>' + opt + '</span></label>'
                    ).join('');
                } else if (q.type === 'text') {
                    inputHtml = '<textarea id="' + q.id + '" class="form-textarea" placeholder="请输入您的回答..."></textarea>';
                } else if (q.type === 'rating') {
                    inputHtml = '<div id="' + q.id + '">' + [1,2,3,4,5].map(i => 
                        '<span onclick="setRating(\'' + q.id + '\', ' + i + ')" style="font-size:2rem;cursor:pointer;" id="' + q.id + '-star' + i + '">★</span>'
                    ).join('') + '</div><input type="hidden" id="' + q.id + '-val">';
                }
                
                card.innerHTML = '<h3>' + (idx + 1) + '. ' + q.title + (q.required ? '<span style="color:red;">*</span>' : '') + '</h3>' +
                    '<div style="margin-top:1rem;">' + inputHtml + '</div>';
                container.appendChild(card);
            });
        }
        
        function setRating(qid, val) {
            for (let i = 1; i <= 5; i++) {
                document.getElementById(qid + '-star' + i).style.color = i <= val ? '#FDCB6E' : '#DFE6E9';
            }
            document.getElementById(qid + '-val').value = val;
        }
        
        function submitResponse() {
            if (!surveyData) return;
            const answers = {};
            let valid = true;
            
            surveyData.questions.forEach((q, idx) => {
                let val = null;
                if (q.type === 'single') {
                    const sel = document.querySelector('input[name="' + q.id + '"]:checked');
                    if (sel) val = sel.value;
                } else if (q.type === 'multiple') {
                    const checked = document.querySelectorAll('input[name="' + q.id + '"]:checked');
                    val = Array.from(checked).map(c => c.value);
                } else if (q.type === 'text') {
                    val = document.getElementById(q.id).value.trim();
                } else if (q.type === 'rating') {
                    val = document.getElementById(q.id + '-val').value;
                }
                
                if (q.required && (!val || (Array.isArray(val) && val.length === 0))) {
                    showToast('请回答第 ' + (idx + 1) + ' 题');
                    valid = false;
                    return;
                }
                answers[q.id] = val;
            });
            
            if (!valid) return;
            
            responses.push({
                id: 'r-' + Date.now(),
                submittedAt: new Date().toISOString(),
                answers: answers
            });
            saveData();
            showToast('提交成功！');
            showPage('home');
        }
        
        function renderResults() {
            const container = document.getElementById('results-container');
            if (!surveyData) {
                container.innerHTML = '<div class="card"><p style="text-align:center;">暂无数据</p></div>';
                return;
            }
            
            let html = '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;margin-bottom:2rem;">' +
                '<div class="card" style="text-align:center;">' +
                '<div style="font-size:2rem;font-weight:bold;color:var(--accent);">' + responses.length + '</div><div>总回复数</div></div>' +
                '<div class="card" style="text-align:center;">' +
                '<div style="font-size:2rem;font-weight:bold;color:var(--accent);">' + surveyData.questions.length + '</div><div>问题数量</div></div>' +
                '<div class="card" style="text-align:center;">' +
                '<div style="font-size:2rem;font-weight:bold;color:var(--accent);">' + 
                (responses.length > 0 ? new Date(responses[responses.length-1].submittedAt).toLocaleDateString() : '-') + 
                '</div><div>最近回复</div></div></div>';
            
            surveyData.questions.forEach(q => {
                html += '<div class="card"><h3>' + q.title + '</h3>';
                
                if (q.type === 'single' || q.type === 'multiple') {
                    const counts = {};
                    q.options.forEach(opt => counts[opt] = 0);
                    responses.forEach(r => {
                        const ans = r.answers[q.id];
                        if (Array.isArray(ans)) {
                            ans.forEach(a => { if (counts[a] !== undefined) counts[a]++; });
                        } else if (ans && counts[ans] !== undefined) {
                            counts[ans]++;
                        }
                    });
                    
                    q.options.forEach(opt => {
                        const count = counts[opt];
                        const pct = responses.length > 0 ? Math.round(count / responses.length * 100) : 0;
                        html += '<div style="margin: 0.5rem 0;">' +
                            '<div style="display:flex;justify-content:space-between;"><span>' + opt + '</span><span>' + count + ' (' + pct + '%)</span></div>' +
                            '<div style="height:8px;background:#eee;border-radius:4px;">' +
                            '<div style="height:100%;background:var(--accent);width:' + pct + '%;border-radius:4px;"></div></div></div>';
                    });
                } else if (q.type === 'rating') {
                    const sum = responses.reduce((a, r) => a + (parseInt(r.answers[q.id]) || 0), 0);
                    const avg = responses.length > 0 ? (sum / responses.length).toFixed(1) : 0;
                    html += '<p>平均分: ' + avg + ' / 5</p>';
                } else if (q.type === 'text') {
                    const texts = responses.map(r => r.answers[q.id]).filter(v => v);
                    html += '<p>共 ' + texts.length + ' 条回答</p>';
                    texts.slice(0, 5).forEach(t => {
                        html += '<div style="background:#f5f5f5;padding:0.75rem;border-radius:8px;margin:0.5rem 0;">' + t + '</div>';
                    });
                    if (texts.length > 5) html += '<p>...还有 ' + (texts.length - 5) + ' 条</p>';
                }
                html += '</div>';
            });
            
            container.innerHTML = html;
        }
        
        function exportToCSV() {
            if (!surveyData || responses.length === 0) { showToast('没有数据可导出'); return; }
            let csv = '提交时间,' + surveyData.questions.map(q => q.title).join(',') + '\\n';
            responses.forEach(r => {
                csv += r.submittedAt + ',';
                csv += surveyData.questions.map(q => {
                    const ans = r.answers[q.id];
                    return Array.isArray(ans) ? ans.join(';') : (ans || '');
                }).join(',') + '\\n';
            });
            downloadFile(csv, 'survey_results.csv', 'text/csv');
        }
        
        function exportToJSON() {
            if (!surveyData) { showToast('没有数据可导出'); return; }
            const data = { survey: surveyData, responses: responses };
            downloadFile(JSON.stringify(data, null, 2), 'survey_data.json', 'application/json');
        }
        
        function downloadFile(content, filename, type) {
            const blob = new Blob([content], { type });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            a.click();
            URL.revokeObjectURL(url);
        }
        
        function clearAllData() {
            if (!confirm('确定要清空所有数据吗？此操作不可恢复！')) return;
            surveyData = null;
            responses = [];
            localStorage.removeItem('survey_data');
            localStorage.removeItem('survey_responses');
            showToast('数据已清空');
            showPage('home');
        }
        
        function showToast(msg) {
            const toast = document.getElementById('toast');
            toast.textContent = msg;
            toast.classList.remove('hidden');
            setTimeout(() => toast.classList.add('hidden'), 3000);
        }
        
        loadData();
        if (window.location.hash === '#fill') showPage('fill');
        else if (window.location.hash === '#results') showPage('results');
        else if (window.location.hash === '#create') showPage('create');
    </script>
</body>
</html>'''

with open('survey.html', 'w', encoding='utf-8') as f:
    f.write(html_content)

print('问卷系统已创建: survey.html')
