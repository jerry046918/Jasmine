$filePath = "C:\Users\tangliying\lobsterai\project\AI 测试数据.xlsx"

# 使用 Excel COM 对象读取
$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false

try {
    $wb = $excel.Workbooks.Open($filePath)
    $ws = $wb.Sheets[1]

    # 获取行列数
    $maxRow = $ws.UsedRange.Rows.Count
    $maxCol = $ws.UsedRange.Columns.Count

    Write-Host "行数：$maxRow"
    Write-Host "列数：$maxCol"

    # 读取列名
    Write-Host "`n=== 列名 ==="
    $colNames = @()
    for ($c = 1; $c -le $maxCol; $c++) {
        $colName = $ws.Cells.Item(1, $c).Text
        $colNames += $colName
        Write-Host "列$c : $colName"
    }

    # 读取前 5 行
    Write-Host "`n=== 前 5 行数据 ==="
    for ($r = 2; $r -le [Math]::Min(6, $maxRow); $r++) {
        $rowData = @()
        for ($c = 1; $c -le $maxCol; $c++) {
            $val = $ws.Cells.Item($r, $c).Text
            $rowData += $val
        }
        Write-Host "行$r : $($rowData -join ', ')"
    }

    # 保存列名到文件
    $colNames | Out-File "C:\Users\tangliying\lobsterai\project\columns.txt" -Encoding UTF8

    $wb.Close($false)
} catch {
    Write-Host "错误：$($_.Exception.Message)"
} finally {
    if ($excel) {
        $excel.Quit()
        [System.Runtime.Interopservices.Marshal]::ReleaseComObject($excel) | Out-Null
    }
    [System.GC]::Collect()
}
