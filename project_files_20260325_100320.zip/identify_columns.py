# -*- coding: utf-8 -*-
"""
使用 win32com 处理 Excel 数据
"""

import pandas as pd
import numpy as np

# 文件路径
input_file = r'C:\Users\tangliying\lobsterai\project\AI 测试数据.xlsx'
output_file = r'C:\Users\tangliying\lobsterai\project\汇总统计结果.xlsx'

print("=== 开始读取数据 ===")

# 读取 Excel 文件
df = pd.read_excel(input_file)
print(f"数据形状：{df.shape}")
print(f"列名：{df.columns.tolist()}")

# 显示前 10 行
print("\n=== 前 10 行数据 ===")
for idx, row in df.head(10).iterrows():
    print(f"行{idx}: {row.to_dict()}")

# 尝试识别列
category_cols = [col for col in df.columns if '分类' in str(col) or 'L3' in str(col) or 'L2' in str(col) or 'L1' in str(col)]
print(f"\n分类列：{category_cols}")

std_time_cols = [col for col in df.columns if '工时' in str(col) or '时间' in str(col) or '时长' in str(col) or '标准' in str(col)]
print(f"标准工时列候选：{std_time_cols}")

volume_cols = [col for col in df.columns if '业务量' in str(col) or '数量' in str(col) or '单量' in str(col) or '件' in str(col) or '票数' in str(col)]
print(f"业务量列候选：{volume_cols}")

numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
print(f"数值列：{numeric_cols}")

# 确定要使用的列
category_col = category_cols[0] if category_cols else None
std_time_col = std_time_cols[0] if std_time_cols else None
volume_col = volume_cols[0] if volume_cols else None

print(f"\n使用分类列：{category_col}")
print(f"使用标准工时列：{std_time_col}")
print(f"使用业务量列：{volume_col}")

# 保存识别结果
info = f"""
=== 数据结构信息 ===
数据形状：{df.shape}
列名：{df.columns.tolist()}

分类列：{category_cols}
标准工时列候选：{std_time_cols}
业务量列候选：{volume_cols}
数值列：{numeric_cols}

使用的列:
- 分类列：{category_col}
- 标准工时列：{std_time_col}
- 业务量列：{volume_col}
"""

with open(r'C:\Users\tangliying\lobsterai\project\column_info.txt', 'w', encoding='utf-8') as f:
    f.write(info)

print("\n列信息已保存到 column_info.txt")
print(info)
