import openpyxl
import csv
import sys

wb = openpyxl.load_workbook(r'C:\Users\tangliying\lobsterai\project\AI 测试数据.xlsx', data_only=True, read_only=True)
ws = wb.active

print(f"Sheet: {ws.title}", file=sys.stderr)

# Read all data
data = []
headers = None
for i, row in enumerate(ws.iter_rows(values_only=True), 1):
    if i == 1:
        headers = row
    else:
        data.append(row)
    if i <= 20:
        print(f"Row {i}: {row}", file=sys.stderr)

wb.close()

# Save to CSV
with open(r'C:\Users\tangliying\lobsterai\project\data_preview.csv', 'w', newline='', encoding='utf-8-sig') as f:
    writer = csv.writer(f)
    writer.writerow(headers)
    writer.writerows(data)

print(f"\nTotal rows: {len(data)}", file=sys.stderr)
print("Saved to data_preview.csv", file=sys.stderr)
