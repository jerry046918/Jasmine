import sys
import os

try:
    # 尝试导入docx
    from docx import Document
    from docx.shared import Inches
except ImportError:
    print("python-docx库未安装，正在尝试安装...")
    import subprocess
    import importlib
    
    try:
        # 尝试使用subprocess安装
        subprocess.check_call([sys.executable, "-m", "pip", "install", "python-docx"])
        print("安装成功，重新加载docx模块...")
        
        # 重新导入
        importlib.invalidate_caches()
        from docx import Document
    except Exception as e:
        print(f"自动安装失败: {e}")
        print("请手动安装: pip install python-docx")
        sys.exit(1)

def create_word_document_from_txt(txt_path, docx_path):
    """将文本文件转换为Word文档"""
    
    # 创建新的Word文档
    doc = Document()
    
    # 读取文本文件内容
    with open(txt_path, 'r', encoding='utf-8') as file:
        content = file.read()
    
    # 按行分割内容
    lines = content.split('\n')
    
    # 添加标题和段落到文档
    for line in lines:
        # 如果是标题（以数字开头或包含中文标题符号）
        if line.strip() and (line.startswith(('一、', '二、', '三、', '四、', '1.', '2.', '3.', '4.')) or 
                             line.strip().endswith(('、', ':')) or 
                             line.startswith('|')):
            doc.add_heading(line.strip(), level=1 if any(c in line for c in ['一、', '二、', '三、', '四、']) else 2)
        elif line.strip() == '':
            # 空行则跳过
            continue
        else:
            # 普通段落
            doc.add_paragraph(line.strip())
    
    # 保存文档
    doc.save(docx_path)
    print(f"文档已成功创建: {docx_path}")

# 主程序
if __name__ == "__main__":
    txt_file_path = "C:\\Users\\tangliying\\lobsterai\\project\\私域平台调研问卷分析报告.txt"
    docx_file_path = "C:\\Users\\tangliying\\lobsterai\\project\\私域平台调研问卷分析报告.docx"
    
    if not os.path.exists(txt_file_path):
        print(f"错误：找不到源文件 {txt_file_path}")
        sys.exit(1)
    
    create_word_document_from_txt(txt_file_path, docx_file_path)