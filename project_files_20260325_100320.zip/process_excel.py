# -*- coding: utf-8 -*-
"""
Excel 数据分类汇总分析脚本
功能：
1. 按类别对数据进行分类汇总 (求和、计数、平均值)
2. 根据标准工时和业务量计算工作耗时，按 L3 分类汇总
3. 输出带图表的汇总统计 Excel 文件
"""

import pandas as pd
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.chart import BarChart, Reference, PieChart
from openpyxl.utils.dataframe import dataframe_to_rows
import sys
import os

# 设置工作目录
os.chdir(r'C:\Users\tangliying\lobsterai\project')

print("=== 开始读取数据 ===", file=sys.stderr)

# 读取 Excel 文件
try:
    df = pd.read_excel('AI 测试数据.xlsx')
    print(f"数据形状：{df.shape}", file=sys.stderr)
    print(f"列名：{df.columns.tolist()}", file=sys.stderr)
except Exception as e:
    print(f"读取 Excel 失败：{e}", file=sys.stderr)
    sys.exit(1)

# 显示前几行数据
print("\n=== 前 10 行数据 ===", file=sys.stderr)
print(df.head(10).to_string(), file=sys.stderr)

# 识别关键列
# 根据用户需求，需要找到：
# - 分类列（分类 2 L3）
# - 标准工时列
# - 业务量列
# - 数值列（用于求和、计数、平均值）

print("\n=== 列数据类型 ===", file=sys.stderr)
for col in df.columns:
    sample = df[col].dropna().head(3).tolist()
    print(f"{col}: {df[col].dtype}, 示例：{sample}", file=sys.stderr)

# 保存数据结构信息
df_info = {
    'columns': df.columns.tolist(),
    'dtypes': df.dtypes.to_dict(),
    'shape': df.shape
}

print("\n=== 数据结构已分析 ===", file=sys.stderr)
print("请查看上述输出，确认列名后继续处理", file=sys.stderr)
