# 使用 .NET 读取 Excel 文件
$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false
$excel.DisplayAlerts = $false

$workbook = $excel.Workbooks.Open("C:\Users\tangliying\lobsterai\project\survey.xlsx")
$worksheet = $workbook.Sheets.Item(1)

$rowCount = $worksheet.UsedRange.Rows.Count
$colCount = $worksheet.UsedRange.Columns.Count

$output = @()
$output += "========================================"
$output += "Survey Analysis Report"
$output += "========================================"
$output += ""
$output += "[Basic Info]"
$output += "  Total Samples: $($rowCount - 1)"
$output += "  Total Questions: $colCount"
$output += ""

$validCols = @()
for ($col = 1; $col -le $colCount; $col++) {
    $header = $worksheet.Cells.Item(1, $col).Text
    if ($header -ne "") {
        $validCols += @{Col = $col; Header = $header}
    }
}

$output += "[Question List]"
for ($i = 0; $i -lt $validCols.Count; $i++) {
    $output += "  $($i + 1). $($validCols[$i].Header)"
}
$output += ""

$output += "[Data Completeness]"
$output += "----------------------------------------"
foreach ($colInfo in $validCols) {
    $col = $colInfo.Col
    $header = $colInfo.Header
    $answered = 0
    for ($row = 2; $row -le $rowCount; $row++) {
        $value = $worksheet.Cells.Item($row, $col).Text
        if ($value -ne "") {
            $answered++
        }
    }
    $rate = [math]::Round(($answered / ($rowCount - 1)) * 100, 1)
    $output += "  $header : $answered/$($rowCount - 1) (${rate}%)"
}
$output += ""

$output += "[Answer Analysis]"
$output += "========================================"

foreach ($colInfo in $validCols) {
    $col = $colInfo.Col
    $header = $colInfo.Header
    
    $output += ""
    $output += "Question: $header"
    $output += "----------------------------------------"
    
    $responses = @{}
    for ($row = 2; $row -le $rowCount; $row++) {
        $value = $worksheet.Cells.Item($row, $col).Text
        if ($value -ne "") {
            if ($responses.ContainsKey($value)) {
                $responses[$value]++
            } else {
                $responses[$value] = 1
            }
        }
    }
    
    $uniqueCount = $responses.Count
    $output += "  Unique Answers: $uniqueCount"
    $output += "  Distribution:"
    
    $sortedResponses = $responses.GetEnumerator() | Sort-Object Value -Descending
    $total = $rowCount - 1
    $displayCount = 0
    foreach ($resp in $sortedResponses) {
        if ($displayCount -ge 15) { break }
        $count = $resp.Value
        $pct = [math]::Round(($count / $total) * 100, 1)
        $displayVal = $resp.Key
        if ($displayVal.Length -gt 200) {
            $displayVal = $displayVal.Substring(0, 200) + "..."
        }
        $bar = "#" * ([math]::Floor($pct / 5))
        $output += "    - $displayVal"
        $output += "      Count: $count (${pct}%) $bar"
        $displayCount++
    }
    
    if ($uniqueCount -gt 15) {
        $output += "    ... and $($uniqueCount - 15) more answers"
    }
}

$workbook.Close()
$excel.Quit()

[System.Runtime.Interopservices.Marshal]::ReleaseComObject($worksheet) | Out-Null
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($workbook) | Out-Null
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($excel) | Out-Null

$output | Out-File -FilePath "C:\Users\tangliying\lobsterai\project\survey_report_final.txt" -Encoding UTF8
Write-Host "Done"
