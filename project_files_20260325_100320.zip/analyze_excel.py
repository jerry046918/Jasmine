import pandas as pd
import sys

# 读取Excel文件
df = pd.read_excel('E:/私域采访.xlsx')

print('=== 文件基本信息 ===')
print(f'总行数: {len(df)}')
print(f'总列数: {len(df.columns)}')
print()

print('=== 列名 ===')
for i, col in enumerate(df.columns, 1):
    print(f'{i}. {col}')
print()

print('=== 前5行数据 ===')
print(df.head())
print()

print('=== 数据类型 ===')
print(df.dtypes)
print()

print('=== 缺失值统计 ===')
print(df.isnull().sum())
print()

# 保存详细信息到文件
with open('C:/Users/tangliying/lobsterai/project/analysis_result.txt', 'w', encoding='utf-8') as f:
    f.write('=== 文件基本信息 ===\n')
    f.write(f'总行数: {len(df)}\n')
    f.write(f'总列数: {len(df.columns)}\n\n')
    
    f.write('=== 列名 ===\n')
    for i, col in enumerate(df.columns, 1):
        f.write(f'{i}. {col}\n')
    f.write('\n')
    
    f.write('=== 前10行数据 ===\n')
    f.write(df.head(10).to_string())
    f.write('\n\n')
    
    f.write('=== 数据类型 ===\n')
    f.write(str(df.dtypes))
    f.write('\n\n')
    
    f.write('=== 缺失值统计 ===\n')
    f.write(str(df.isnull().sum()))
    f.write('\n\n')
    
    # 对每个文本列统计唯一值
    f.write('=== 各列唯一值统计 ===\n')
    for col in df.columns:
        unique_count = df[col].nunique()
        f.write(f'{col}: {unique_count} 个唯一值\n')
        
        # 如果是文本列且唯一值不多，列出分布
        if df[col].dtype == 'object' and unique_count <= 20:
            f.write(f'  分布:\n')
            value_counts = df[col].value_counts()
            for val, count in value_counts.items():
                pct = count / len(df) * 100
                f.write(f'    - {val}: {count} ({pct:.1f}%)\n')
        f.write('\n')

print('分析完成！结果已保存到 analysis_result.txt')
