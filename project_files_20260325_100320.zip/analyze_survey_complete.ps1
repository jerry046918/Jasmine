# 使用 .NET 读取 Excel 文件 - 完整分析
$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false
$excel.DisplayAlerts = $false

$workbook = $excel.Workbooks.Open("C:\Users\tangliying\lobsterai\project\survey.xlsx")
$worksheet = $workbook.Sheets.Item(1)

# 获取行数和列数
$rowCount = $worksheet.UsedRange.Rows.Count
$colCount = $worksheet.UsedRange.Columns.Count

$output = @()
$output += "========================================"
$output += "📊 私域采访调研问卷分析报告"
$output += "========================================"
$output += ""

# 基本信息
$output += "【一、基本信息】"
$output += "  • 有效样本数: $($rowCount - 1) 份"
$output += "  • 问题数量: $colCount 个"
$output += ""

# 获取有效的列（非空标题）
$validCols = @()
for ($col = 1; $col -le $colCount; $col++) {
    $header = $worksheet.Cells.Item(1, $col).Text
    if ($header -ne "") {
        $validCols += @{Col = $col; Header = $header}
    }
}

$output += "【二、问题列表】"
for ($i = 0; $i -lt $validCols.Count; $i++) {
    $output += "  $($i + 1). $($validCols[$i].Header)"
}
$output += ""

# 数据完整性统计
$output += "【三、数据完整性】"
$output += "-" * 40
foreach ($colInfo in $validCols) {
    $col = $colInfo.Col
    $header = $colInfo.Header
    $answered = 0
    for ($row = 2; $row -le $rowCount; $row++) {
        $value = $worksheet.Cells.Item($row, $col).Text
        if ($value -ne "") {
            $answered++
        }
    }
    $rate = [math]::Round(($answered / ($rowCount - 1)) * 100, 1)
    $status = if ($rate -ge 90) { "✓" } elseif ($rate -ge 70) { "⚠" } else { "✗" }
    $output += "  $status $header : $answered/$($rowCount - 1) ($rate%)"
}
$output += ""

# 各问题回答统计
$output += "【四、各问题回答分析】"
$output += "========================================"

foreach ($colInfo in $validCols) {
    $col = $colInfo.Col
    $header = $colInfo.Header
    
    $output += ""
    $output += "▶ 问题: $header"
    $output += "-" * 40
    
    # 统计各回答出现次数
    $responses = @{}
    for ($row = 2; $row -le $rowCount; $row++) {
        $value = $worksheet.Cells.Item($row, $col).Text
        if ($value -ne "") {
            if ($responses.ContainsKey($value)) {
                $responses[$value]++
            } else {
                $responses[$value] = 1
            }
        }
    }
    
    $uniqueCount = $responses.Count
    $output += "  不同回答数: $uniqueCount"
    $output += "  回答分布:"
    
    # 按出现次数排序
    $sortedResponses = $responses.GetEnumerator() | Sort-Object Value -Descending
    $total = $rowCount - 1
    $displayCount = 0
    foreach ($resp in $sortedResponses) {
        if ($displayCount -ge 10) { break }
        $count = $resp.Value
        $pct = [math]::Round(($count / $total) * 100, 1)
        $displayVal = $resp.Key
        if ($displayVal.Length -gt 50) {
            $displayVal = $displayVal.Substring(0, 50) + "..."
        }
        $bar = "█" * [math]::Floor($pct / 5)
        $output += "    • $displayVal : $count ($pct%) $bar"
        $displayCount++
    }
    
    if ($uniqueCount -gt 10) {
        $output += "    ... 还有 $($uniqueCount - 10) 个其他回答"
    }
}

$workbook.Close()
$excel.Quit()

# 释放 COM 对象
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($worksheet) | Out-Null
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($workbook) | Out-Null
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($excel) | Out-Null

# 写入文件
$output | Out-File -FilePath "C:\Users\tangliying\lobsterai\project\survey_full_report.txt" -Encoding UTF8
Write-Host "报告已生成: survey_full_report.txt"
