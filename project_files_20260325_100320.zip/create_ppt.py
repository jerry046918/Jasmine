#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
创建自我介绍 PPT - 简约商务风格
"""

import sys
import os

# 尝试导入 pptx
try:
    from pptx import Presentation
    from pptx.util import Inches, Pt, Cm
    from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.dml.color import RgbColor
    from pptx.oxml.ns import nsmap
    from pptx.oxml import parse_xml
    PPTX_AVAILABLE = True
except ImportError:
    PPTX_AVAILABLE = False
    print("python-pptx 不可用，尝试安装...")

if not PPTX_AVAILABLE:
    import subprocess
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'python-pptx'])
    from pptx import Presentation
    from pptx.util import Inches, Pt, Cm
    from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.dml.color import RgbColor

def create_self_introduction_ppt():
    """创建自我介绍 PPT"""

    # 创建演示文稿
    prs = Presentation()

    # 设置宽屏 16:9
    prs.slide_width = Cm(33.867)
    prs.slide_height = Cm(19.05)

    # 定义配色方案 - 蓝色系商务风格
    COLORS = {
        'dark_blue': RgbColor(30, 58, 138),      # 深蓝色 - 主色
        'medium_blue': RgbColor(59, 130, 246),   # 中蓝色 - 强调色
        'light_blue': RgbColor(219, 234, 254),   # 浅蓝色 - 背景色
        'gray': RgbColor(107, 114, 128),         # 灰色 - 辅助文字
        'dark_gray': RgbColor(55, 65, 81),       # 深灰色 - 正文
        'white': RgbColor(255, 255, 255),        # 白色
        'light_gray': RgbColor(243, 244, 246)    # 浅灰色 - 背景
    }

    # 定义字体
    FONT_NAME = 'Microsoft YaHei'  # 微软雅黑

    def add_title_slide(prs, title, subtitle):
        """添加标题页"""
        slide = prs.slides.add_slide(prs.slide_layouts[6])  # 空白版式

        # 添加蓝色背景矩形
        shape = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE,
            0, 0, prs.slide_width, prs.slide_height
        )
        shape.fill.solid()
        shape.fill.fore_color.rgb = COLORS['dark_blue']
        shape.line.fill.background()

        # 添加装饰性几何图形
        decor = slide.shapes.add_shape(
            MSO_SHAPE.TRAPEZOID,
            Cm(0), Cm(14), Cm(15), Cm(5)
        )
        decor.fill.solid()
        decor.fill.fore_color.rgb = COLORS['medium_blue']
        decor.line.fill.background()
        decor.rotation = 180

        # 添加标题
        title_box = slide.shapes.add_textbox(Cm(3), Cm(5), Cm(28), Cm(4))
        tf = title_box.text_frame
        p = tf.paragraphs[0]
        p.text = title
        p.font.size = Pt(54)
        p.font.bold = True
        p.font.color.rgb = COLORS['white']
        p.font.name = FONT_NAME
        p.alignment = PP_ALIGN.CENTER

        # 添加副标题
        subtitle_box = slide.shapes.add_textbox(Cm(3), Cm(9), Cm(28), Cm(3))
        tf = subtitle_box.text_frame
        p = tf.paragraphs[0]
        p.text = subtitle
        p.font.size = Pt(28)
        p.font.color.rgb = COLORS['light_blue']
        p.font.name = FONT_NAME
        p.alignment = PP_ALIGN.CENTER

        return slide

    def add_content_slide(prs, title, content_items, slide_type='bullet'):
        """添加内容页"""
        slide = prs.slides.add_slide(prs.slide_layouts[6])

        # 添加顶部蓝色条
        header = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE,
            0, 0, prs.slide_width, Cm(2.5)
        )
        header.fill.solid()
        header.fill.fore_color.rgb = COLORS['dark_blue']
        header.line.fill.background()

        # 添加标题
        title_box = slide.shapes.add_textbox(Cm(1.5), Cm(0.5), Cm(20), Cm(2))
        tf = title_box.text_frame
        p = tf.paragraphs[0]
        p.text = title
        p.font.size = Pt(32)
        p.font.bold = True
        p.font.color.rgb = COLORS['white']
        p.font.name = FONT_NAME

        # 添加装饰线条
        line = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE,
            Cm(1.5), Cm(2.3), Cm(3), Cm(0.15)
        )
        line.fill.solid()
        line.fill.fore_color.rgb = COLORS['medium_blue']
        line.line.fill.background()

        if slide_type == 'bullet':
            # 添加项目符号内容
            content_box = slide.shapes.add_textbox(Cm(2), Cm(3.5), Cm(29), Cm(13))
            tf = content_box.text_frame
            tf.word_wrap = True

            for i, item in enumerate(content_items):
                if i == 0:
                    p = tf.paragraphs[0]
                else:
                    p = tf.add_paragraph()
                p.text = item
                p.font.size = Pt(20)
                p.font.color.rgb = COLORS['dark_gray']
                p.font.name = FONT_NAME
                p.space_after = Pt(12)
                p.level = 0

        elif slide_type == 'timeline':
            # 时间线布局
            start_y = Cm(4)
            item_height = Cm(2.5)

            for i, item in enumerate(content_items):
                # 添加时间点圆圈
                circle = slide.shapes.add_shape(
                    MSO_SHAPE.OVAL,
                    Cm(2), start_y + Cm(i * item_height), Cm(0.8), Cm(0.8)
                )
                circle.fill.solid()
                circle.fill.fore_color.rgb = COLORS['medium_blue']
                circle.line.fill.background()

                # 添加连接线
                if i < len(content_items) - 1:
                    line = slide.shapes.add_shape(
                        MSO_SHAPE.RECTANGLE,
                        Cm(2.4), start_y + Cm(i * item_height) + Cm(0.8),
                        Cm(0.1), Cm(item_height)
                    )
                    line.fill.solid()
                    line.fill.fore_color.rgb = COLORS['light_gray']
                    line.line.fill.background()

                # 添加内容框
                content_box = slide.shapes.add_shape(
                    MSO_SHAPE.ROUNDED_RECTANGLE,
                    Cm(3.5), start_y + Cm(i * item_height), Cm(27), Cm(2)
                )
                content_box.fill.solid()
                content_box.fill.fore_color.rgb = COLORS['light_gray']
                content_box.line.fill.background()

                tf = content_box.text_frame
                tf.word_wrap = True
                p = tf.paragraphs[0]
                p.text = item
                p.font.size = Pt(18)
                p.font.color.rgb = COLORS['dark_gray']
                p.font.name = FONT_NAME

        elif slide_type == 'skills':
            # 技能展示布局
            start_y = Cm(4)
            item_height = Cm(2)

            for i, item in enumerate(content_items):
                # 技能名称
                name_box = slide.shapes.add_textbox(Cm(2), start_y + Cm(i * item_height), Cm(8), Cm(1.5))
                tf = name_box.text_frame
                p = tf.paragraphs[0]
                p.text = item['name']
                p.font.size = Pt(18)
                p.font.bold = True
                p.font.color.rgb = COLORS['dark_gray']
                p.font.name = FONT_NAME

                # 技能条背景
                bar_bg = slide.shapes.add_shape(
                    MSO_SHAPE.RECTANGLE,
                    Cm(10), start_y + Cm(i * item_height) + Cm(0.3),
                    Cm(18), Cm(0.6)
                )
                bar_bg.fill.solid()
                bar_bg.fill.fore_color.rgb = COLORS['light_gray']
                bar_bg.line.fill.background()

                # 技能进度条
                bar_width = 18 * item['level'] / 100
                bar = slide.shapes.add_shape(
                    MSO_SHAPE.RECTANGLE,
                    Cm(10), start_y + Cm(i * item_height) + Cm(0.3),
                    Cm(bar_width), Cm(0.6)
                )
                bar.fill.solid()
                bar.fill.fore_color.rgb = COLORS['medium_blue']
                bar.line.fill.background()

                # 技能程度文字
                level_box = slide.shapes.add_textbox(Cm(28), start_y + Cm(i * item_height), Cm(4), Cm(1.5))
                tf = level_box.text_frame
                p = tf.paragraphs[0]
                p.text = f"{item['level']}%"
                p.font.size = Pt(16)
                p.font.color.rgb = COLORS['gray']
                p.font.name = FONT_NAME

        elif slide_type == 'cards':
            # 卡片式布局
            card_width = Cm(14)
            card_height = Cm(6)
            gap = Cm(1)
            start_x = Cm(2)
            start_y = Cm(4)

            for i, item in enumerate(content_items):
                row = i // 2
                col = i % 2

                x = start_x + col * (card_width + gap)
                y = start_y + row * (card_height + gap)

                # 添加卡片背景
                card = slide.shapes.add_shape(
                    MSO_SHAPE.ROUNDED_RECTANGLE,
                    x, y, card_width, card_height
                )
                card.fill.solid()
                card.fill.fore_color.rgb = COLORS['light_blue']
                card.line.fill.background()

                # 添加卡片内容
                tf = card.text_frame
                tf.word_wrap = True
                tf.text = item
                for p in tf.paragraphs:
                    p.font.size = Pt(16)
                    p.font.color.rgb = COLORS['dark_gray']
                    p.font.name = FONT_NAME

        elif slide_type == 'ending':
            # 结束页布局
            # 添加蓝色背景
            bg = slide.shapes.add_shape(
                MSO_SHAPE.RECTANGLE,
                0, 0, prs.slide_width, prs.slide_height
            )
            bg.fill.solid()
            bg.fill.fore_color.rgb = COLORS['dark_blue']
            bg.line.fill.background()

            # 添加感谢文字
            thanks_box = slide.shapes.add_textbox(Cm(3), Cm(6), Cm(28), Cm(5))
            tf = thanks_box.text_frame
            p = tf.paragraphs[0]
            p.text = content_items.get('thanks', '感谢聆听')
            p.font.size = Pt(48)
            p.font.bold = True
            p.font.color.rgb = COLORS['white']
            p.font.name = FONT_NAME
            p.alignment = PP_ALIGN.CENTER

            # 添加联系方式
            contact_box = slide.shapes.add_textbox(Cm(3), Cm(11), Cm(28), Cm(4))
            tf = contact_box.text_frame
            p = tf.paragraphs[0]
            p.text = content_items.get('contact', '联系方式')
            p.font.size = Pt(24)
            p.font.color.rgb = COLORS['light_blue']
            p.font.name = FONT_NAME
            p.alignment = PP_ALIGN.CENTER

        return slide

    # ============ 创建各页内容 ============

    # 1. 封面页
    add_title_slide(prs, '自我介绍', 'Personal Introduction')

    # 2. 个人概况页
    profile_content = [
        '姓名：[您的姓名]',
        '联系电话：[您的电话号码]',
        '电子邮箱：[您的邮箱地址]',
        '所在城市：[您所在的城市]',
        '',
        '个人标签：',
        '  • 积极进取 | 团队协作 | 创新思维',
        '  • 学习能力强 | 责任心强 | 执行力高',
        '',
        '自我介绍：',
        '  简洁有力的个人简介，突出核心优势和职业特点...'
    ]
    add_content_slide(prs, '个人概况', profile_content)

    # 3. 教育背景页 (时间线布局)
    education_content = [
        '[最高学历] | [学校名称] | [专业名称] | [入学年份]-[毕业年份]',
        '  主修课程：[核心课程列表]',
        '   GPA：[如果优秀可填写]',
        '',
        '[本科学历] | [学校名称] | [专业名称] | [入学年份]-[毕业年份]',
        '  主修课程：[核心课程列表]',
        '',
        '校园荣誉：',
        '  • [奖学金/荣誉称号等]',
        '  • [校园活动/社团经历]'
    ]
    add_content_slide(prs, '教育背景', education_content)

    # 4. 工作经历页 (时间线布局)
    work_content = [
        '[最近公司] | [职位名称] | [入职时间]-[至今/离职时间]',
        '  • 主要职责：[工作职责描述]',
        '  • 核心成就：[工作成果]',
        '',
        '[前公司] | [职位名称] | [入职时间]-[离职时间]',
        '  • 主要职责：[工作职责描述]',
        '  • 核心成就：[工作成果]',
        '',
        '[更早公司] | [职位名称] | [入职时间]-[离职时间]',
        '  • 主要职责：[工作职责描述]'
    ]
    add_content_slide(prs, '工作经历', work_content)

    # 5. 项目经验页 (卡片布局)
    project_content = [
        '【项目名称 1】\n角色：[项目角色]\n成果：[项目成果/数据]',
        '【项目名称 2】\n角色：[项目角色]\n成果：[项目成果/数据]',
        '【项目名称 3】\n角色：[项目角色]\n成果：[项目成果/数据]',
        '【项目名称 4】\n角色：[项目角色]\n成果：[项目成果/数据]'
    ]
    add_content_slide(prs, '项目经验', project_content, slide_type='cards')

    # 6. 专业技能页
    skills_content = [
        {'name': '专业技能 1', 'level': 90},
        {'name': '专业技能 2', 'level': 85},
        {'name': '专业技能 3', 'level': 80},
        {'name': '专业技能 4', 'level': 75},
        {'name': '语言/工具', 'level': 85},
        {'name': '软技能', 'level': 90}
    ]
    add_content_slide(prs, '专业技能', skills_content, slide_type='skills')

    # 7. 荣誉证书页
    certificate_content = [
        '专业认证：',
        '  • [证书名称 1] | [颁发机构] | [获得时间]',
        '  • [证书名称 2] | [颁发机构] | [获得时间]',
        '  • [证书名称 3] | [颁发机构] | [获得时间]',
        '',
        '荣誉奖项：',
        '  • [奖项名称 1] | [颁发单位] | [获得时间]',
        '  • [奖项名称 2] | [颁发单位] | [获得时间]',
        '',
        '其他资质：',
        '  • [资质证书/语言能力等]'
    ]
    add_content_slide(prs, '荣誉证书', certificate_content)

    # 8. 兴趣爱好页
    hobby_content = [
        '运动健身：',
        '  • [运动项目] - 保持健康体魄，培养毅力',
        '',
        '阅读学习：',
        '  • [书籍类型] - 持续学习，拓展知识面',
        '',
        '艺术爱好：',
        '  • [艺术项目] - 培养审美，提升创造力',
        '',
        '社会实践：',
        '  • [志愿活动/社团] - 回馈社会，锻炼能力',
        '',
        '个人特长：',
        '  • [特殊技能/才能]'
    ]
    add_content_slide(prs, '兴趣爱好', hobby_content)

    # 9. 未来规划页
    planning_content = [
        '短期目标（1-2 年）：',
        '  • [具体目标 1] - 提升专业技能',
        '  • [具体目标 2] - 积累项目经验',
        '  • [具体目标 3] - 拓展行业视野',
        '',
        '中期目标（3-5 年）：',
        '  • [发展方向] - 成为领域专家',
        '  • [能力提升] - 提升管理能力',
        '',
        '长期愿景：',
        '  • [职业愿景] - 实现职业理想',
        '  • [个人价值] - 创造更大价值'
    ]
    add_content_slide(prs, '未来规划', planning_content)

    # 10. 结束页
    ending_content = {
        'thanks': '感谢聆听',
        'contact': '联系方式：[电话] | [邮箱]\nTHANK YOU'
    }
    add_content_slide(prs, '', ending_content, slide_type='ending')

    # 保存文件
    output_path = 'C:/Users/tangliying/lobsterai/project/self_introduction.pptx'
    prs.save(output_path)
    print(f"PPT 创建成功！保存路径：{output_path}")

    return output_path

if __name__ == '__main__':
    create_self_introduction_ppt()
