@echo off
echo 启动定时提醒服务...
echo 当前时间: %DATE% %TIME%

REM 运行PowerShell脚本
powershell -ExecutionPolicy Bypass -File "%~dp0reminders.ps1"

echo 定时提醒服务已结束
pause