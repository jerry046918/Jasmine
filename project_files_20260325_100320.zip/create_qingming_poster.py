import numpy as np
import matplotlib.pyplot as plt
import calendar
from datetime import datetime
import matplotlib.patches as patches

# Set up the figure with dark blue background
fig, ax = plt.subplots(figsize=(12, 16))
fig.patch.set_facecolor('#001f3f')  # Deep navy blue

# Title
plt.text(0.5, 0.95, '清明节放假通知', fontsize=40, fontweight='bold',
         ha='center', va='top', color='white',
         transform=ax.transAxes,
         bbox=dict(boxstyle="round,pad=0.3", facecolor='#003366', alpha=0.8))

# Subtitle
plt.text(0.5, 0.90, 'Qingming Festival Holiday Notice', fontsize=18,
         ha='center', va='top', color='#FFDC00',  # Gold yellow
         transform=ax.transAxes)

# Current month calendar for April 2026 (as an example)
year = 2026
month = 4
cal = calendar.monthcalendar(year, month)

# Draw calendar
start_y = 0.75
cell_height = 0.08
cell_width = 0.12
start_x = 0.5 - (7 * cell_width) / 2

# Draw day headers
days_of_week = ['周一\nMon', '周二\nTue', '周三\nWed', '周四\nThu', '周五\nFri', '周六\nSat', '周日\nSun']
for i, day_header in enumerate(days_of_week):
    plt.text(start_x + i * cell_width, start_y + 0.05, day_header,
             fontsize=12, ha='center', va='center',
             color='#FFDC00', fontweight='bold',
             transform=ax.transAxes)

# Draw calendar cells
for week_idx, week in enumerate(cal):
    for day_idx, day in enumerate(week):
        x = start_x + day_idx * cell_width
        y = start_y - week_idx * cell_height

        # Determine if this day is a holiday (April 4-6, 2026 for Qingming Festival)
        is_holiday = (day >= 4 and day <= 6) if day != 0 else False

        # Draw cell background
        rect_color = '#FF4136' if is_holiday else '#FFFFFF'  # Red for holiday, white for regular day
        rect_alpha = 0.7 if is_holiday else 0.9
        rect = patches.Rectangle((x - cell_width/2, y - cell_height/2),
                                 cell_width, cell_height,
                                 linewidth=2, edgecolor='white',
                                 facecolor=rect_color, alpha=rect_alpha,
                                 transform=ax.transAxes)
        ax.add_patch(rect)

        # Day number
        text_color = 'white' if is_holiday else '#001f3f'  # White on red, dark on white
        if day != 0:
            plt.text(x, y, str(day), fontsize=14,
                     ha='center', va='center',
                     color=text_color, fontweight='bold' if is_holiday else 'normal',
                     transform=ax.transAxes)

# Holiday information box
info_box_x = 0.5
info_box_y = 0.55
info_width = 0.7
info_height = 0.15

# Draw information box
info_rect = patches.Rectangle((info_box_x - info_width/2, info_box_y - info_height/2),
                              info_width, info_height,
                              linewidth=2, edgecolor='#FFDC00',
                              facecolor='#003366', alpha=0.9,
                              transform=ax.transAxes)
ax.add_patch(info_rect)

# Holiday details
plt.text(info_box_x, info_box_y + 0.04, '清明节放假安排',
         fontsize=20, fontweight='bold', ha='center', va='center',
         color='white', transform=ax.transAxes)

plt.text(info_box_x, info_box_y - 0.01, '4月4日-4月6日放假，共3天',
         fontsize=16, ha='center', va='center',
         color='#FFDC00', transform=ax.transAxes)

plt.text(info_box_x, info_box_y - 0.05, '4月7日(星期二)正常上班',
         fontsize=14, ha='center', va='center',
         color='white', transform=ax.transAxes)

# Additional notice
notice_y = 0.45
plt.text(0.5, notice_y + 0.04, '温馨提示', fontsize=20,
         fontweight='bold', ha='center', va='center',
         color='#FFDC00', transform=ax.transAxes)

plt.text(0.5, notice_y, '清明时节雨纷纷，请注意天气变化，',
         fontsize=14, ha='center', va='center',
         color='white', transform=ax.transAxes)

plt.text(0.5, notice_y - 0.03, '合理安排出行计划',
         fontsize=14, ha='center', va='center',
         color='white', transform=ax.transAxes)

# Decorative elements - Spring motifs
# Simple flower-like shapes to represent spring season
for i in range(5):
    flower_x = 0.15 + i * 0.17
    flower_y = 0.25

    # Draw simple flower
    circle = patches.Circle((flower_x, flower_y), 0.02,
                            facecolor='#FF4136', edgecolor='white',
                            linewidth=1, transform=ax.transAxes)
    ax.add_patch(circle)

    # Petals
    for angle in range(0, 360, 60):
        rad = np.deg2rad(angle)
        petal_x = flower_x + 0.03 * np.cos(rad)
        petal_y = flower_y + 0.03 * np.sin(rad)
        petal = patches.Circle((petal_x, petal_y), 0.015,
                               facecolor='#B10DC9', edgecolor='white',
                               linewidth=1, transform=ax.transAxes)
        ax.add_patch(petal)

# Bottom decorative border
bottom_y = 0.1
for i in range(20):
    line_x = 0.05 + i * 0.05
    line = patches.Rectangle((line_x - 0.005, bottom_y - 0.01),
                             0.01, 0.02,
                             facecolor='#FFDC00', alpha=0.7,
                             transform=ax.transAxes)
    ax.add_patch(line)

# Company signature
plt.text(0.5, 0.05, '公司名称 | Company Name',
         fontsize=14, ha='center', va='center',
         color='#FFDC00', fontweight='bold',
         transform=ax.transAxes)

plt.text(0.5, 0.02, f'{datetime.now().strftime("%Y年%m月%d日")}',
         fontsize=12, ha='center', va='center',
         color='white',
         transform=ax.transAxes)

# Set axis properties
ax.set_xlim(0, 1)
ax.set_ylim(0, 1)
ax.axis('off')

# Save the poster
plt.savefig('qingming_festival_notice.png', dpi=300, bbox_inches='tight',
            facecolor='#001f3f')
plt.show()