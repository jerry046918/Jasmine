# -*- coding: utf-8 -*-
import pandas as pd
import sys

# 读取Excel文件
df = pd.read_excel('survey.xlsx')

# 重定向输出到文件
sys.stdout = open('survey_report.txt', 'w', encoding='utf-8')

print("=" * 60)
print("📊 私域采访调研问卷分析报告")
print("=" * 60)
print()

# 基本信息
print("【一、基本信息】")
print(f"  • 有效样本数: {len(df)} 份")
print(f"  • 问题数量: {len(df.columns)} 个")
print()

# 问题列表
print("【二、问题列表】")
for i, col in enumerate(df.columns, 1):
    print(f"  {i}. {col}")
print()

# 数据完整性
print("【三、数据完整性】")
print("-" * 40)
for col in df.columns:
    answered = df[col].notna().sum()
    missing = df[col].isna().sum()
    rate = (answered / len(df)) * 100
    status = "✓" if rate >= 90 else "⚠" if rate >= 70 else "✗"
    print(f"  {status} {col}: {answered}/{len(df)} ({rate:.1f}%)")
print()

# 各问题详细分析
print("【四、各问题回答分布】")
print("=" * 60)

for idx, col in enumerate(df.columns, 1):
    print(f"\n▶ 问题 {idx}: {col}")
    print("-" * 40)
    
    # 唯一值数量
    unique_count = df[col].nunique()
    print(f"  不同回答数: {unique_count}")
    
    # 如果是数值类型，显示统计信息
    if pd.api.types.is_numeric_dtype(df[col]):
        print(f"  平均值: {df[col].mean():.2f}")
        print(f"  中位数: {df[col].median():.2f}")
        print(f"  最小值: {df[col].min()}")
        print(f"  最大值: {df[col].max()}")
    
    # 显示回答分布（前10个最常见）
    print(f"  回答分布:")
    value_counts = df[col].value_counts().head(10)
    total = len(df)
    for val, count in value_counts.items():
        pct = (count / total) * 100
        bar = "█" * int(pct / 5)  # 简单的条形图
        display_val = str(val)[:40] if len(str(val)) > 40 else str(val)
        print(f"    • {display_val}: {count} ({pct:.1f}%) {bar}")
    
    if unique_count > 10:
        print(f"    ... 还有 {unique_count - 10} 个其他回答")

print()
print("=" * 60)
print("分析完成")
print("=" * 60)

sys.stdout.close()
print("报告已生成: survey_report.txt")
