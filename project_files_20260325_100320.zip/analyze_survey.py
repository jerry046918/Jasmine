import pandas as pd

# 读取Excel文件
df = pd.read_excel('survey.xlsx')

# 输出基本信息
print("=== 问卷基本信息 ===")
print(f"总记录数: {len(df)}")
print(f"总问题数: {len(df.columns)}")
print()

print("=== 问题列表 ===")
for i, col in enumerate(df.columns, 1):
    print(f"{i}. {col}")
print()

print("=== 前3行样本数据 ===")
print(df.head(3).to_string())
print()

print("=== 数据完整性 ===")
missing = df.isnull().sum()
for col in df.columns:
    missing_count = missing[col]
    pct = (missing_count / len(df)) * 100
    print(f"{col}: {len(df) - missing_count}/{len(df)} (缺失 {missing_count}, {pct:.1f}%)")
print()

print("=== 各问题回答分布 ===")
for col in df.columns:
    unique_count = df[col].nunique()
    print(f"\n【{col}】")
    print(f"  唯一值数量: {unique_count}")
    
    # 显示值分布（前10个最常见的）
    value_counts = df[col].value_counts().head(10)
    print(f"  回答分布:")
    for val, count in value_counts.items():
        pct = (count / len(df)) * 100
        display_val = str(val)[:50] if len(str(val)) > 50 else str(val)
        print(f"    - {display_val}: {count} ({pct:.1f}%)")
