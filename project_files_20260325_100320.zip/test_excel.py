import pandas as pd

# 读取Excel文件
df = pd.read_excel('E:/私域采访.xlsx')

# 基本信息
output = []
output.append('=== 文件基本信息 ===')
output.append(f'总行数: {len(df)}')
output.append(f'总列数: {len(df.columns)}')
output.append('')

output.append('=== 列名 ===')
for i, col in enumerate(df.columns, 1):
    output.append(f'{i}. {col}')
output.append('')

# 写入文件
with open('C:/Users/tangliying/lobsterai/project/analysis_result.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(output))

print('Done')
