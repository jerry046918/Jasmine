# PowerShell script to create a Word document from a text file
param(
    [string]$InputFile = "C:\Users\tangliying\lobsterai\project\私域平台调研问卷分析报告.txt",
    [string]$OutputFile = "C:\Users\tangliying\lobsterai\project\私域平台调研问卷分析报告.docx"
)

# Check if the input file exists
if (-not (Test-Path $InputFile)) {
    Write-Host "错误：找不到源文件 $InputFile"
    exit 1
}

# Create a new Word application object
try {
    $Word = New-Object -ComObject Word.Application
    $Word.Visible = $false
    
    # Create a new document
    $Document = $Word.Documents.Add()
    $Selection = $Word.Selection
    
    # Read the content of the text file
    $Content = Get-Content -Path $InputFile -Encoding UTF8
    
    # Process each line
    foreach ($Line in $Content) {
        $TrimmedLine = $Line.Trim()
        
        # Check if line is empty
        if ([string]::IsNullOrEmpty($TrimmedLine)) {
            # Add an empty paragraph for blank lines
            $Selection.TypeParagraph()
            continue
        }
        
        # Check if the line is a heading (starts with section markers)
        $IsHeading = $false
        
        # Add the line to the document
        $Selection.TypeText($TrimmedLine)
        $Selection.TypeParagraph()
        
        # Simple detection for potential headings (could be enhanced)
        if ($TrimmedLine -match "^[一二三四五六七八九十]+、" -or 
            $TrimmedLine -match "^[\d]+[\.．]") {
            
            # Apply heading style
            $Selection.MoveUp(2, 1) | Out-Null  # Move back to the previous paragraph
            $Selection.Style = "Heading 1"
            $IsHeading = $true
        }
        
        # Add some spacing after headings
        if ($IsHeading) {
            $Selection.TypeParagraph()
        }
    }
    
    # Save the document
    $Document.SaveAs([ref]$OutputFile)
    Write-Host "文档已成功创建: $OutputFile"
    
    # Close the document and quit Word application
    $Document.Close()
    $Word.Quit()
    
    # Release COM objects
    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($Document) | Out-Null
    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($Word) | Out-Null
    [System.GC]::Collect()
    [System.GC]::WaitForPendingFinalizers()
} catch {
    Write-Host "创建Word文档时发生错误: $_"
    if ($Word) {
        $Word.Quit()
    }
}