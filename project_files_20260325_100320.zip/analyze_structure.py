# -*- coding: utf-8 -*-
"""
Excel 数据分类汇总分析脚本
功能：
1. 按类别对数据进行分类汇总 (求和、计数、平均值)
2. 根据标准工时和业务量计算工作耗时，按 L3 分类汇总
3. 输出带图表的汇总统计 Excel 文件
"""

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.chart import BarChart, Reference, PieChart
from openpyxl.utils.dataframe import dataframe_to_rows
import numpy as np

# 文件路径
input_file = r'C:\Users\tangliying\lobsterai\project\AI 测试数据.xlsx'
output_file = r'C:\Users\tangliying\lobsterai\project\汇总统计结果.xlsx'

print("=== 开始读取数据 ===")

# 读取 Excel 文件
df = pd.read_excel(input_file)
print(f"数据形状：{df.shape}")
print(f"列名：{df.columns.tolist()}")

# 显示前几行
print("\n=== 前 5 行数据 ===")
print(df.head())

# 尝试识别列
# 查找分类列（包含"分类"或"L3"）
category_cols = [col for col in df.columns if '分类' in col or 'L3' in col or 'L2' in col or 'L1' in col]
print(f"\n=== 分类列：{category_cols}")

# 查找标准工时列
std_time_cols = [col for col in df.columns if '工时' in col or '时间' in col or '时长' in col]
print(f"标准工时列候选：{std_time_cols}")

# 查找业务量列
volume_cols = [col for col in df.columns if '业务量' in col or '数量' in col or '单量' in col or '件' in col]
print(f"业务量列候选：{volume_cols}")

# 查找数值列
numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
print(f"数值列：{numeric_cols}")

# 确定要使用的列
# 使用第一个分类列作为主要分类
if category_cols:
    category_col = category_cols[0]  # 如"分类 2 L3"
    print(f"\n使用分类列：{category_col}")
else:
    category_col = None
    print("\n警告：未找到分类列")

# 使用第一个标准工时列
if std_time_cols:
    std_time_col = std_time_cols[0]
    print(f"使用标准工时列：{std_time_col}")
else:
    std_time_col = None
    print("警告：未找到标准工时列")

# 使用第一个业务量列
if volume_cols:
    volume_col = volume_cols[0]
    print(f"使用业务量列：{volume_col}")
else:
    volume_col = None
    print("警告：未找到业务量列")

print("\n=== 数据基本信息 ===")
print(df.describe())
