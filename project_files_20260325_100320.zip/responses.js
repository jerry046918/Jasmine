const { kv } = require('@vercel/kv');

module.exports = async (req, res) => {
  // 设置 CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // 简单认证
    const authHeader = req.headers.authorization;
    const adminPassword = process.env.ADMIN_PASSWORD || 'admin123';
    
    if (!authHeader || authHeader !== `Bearer ${adminPassword}`) {
      return res.status(401).json({ error: '未授权访问' });
    }

    // 获取响应列表
    const responseList = await kv.get('response_list') || [];
    
    // 获取所有详细数据
    const responses = [];
    for (const item of responseList) {
      const data = await kv.get(`response:${item.id}`);
      if (data) {
        responses.push(typeof data === 'string' ? JSON.parse(data) : data);
      }
    }

    // 按时间倒序排列
    responses.sort((a, b) => new Date(b.submitted_at) - new Date(a.submitted_at));

    return res.status(200).json({
      success: true,
      count: responses.length,
      responses
    });

  } catch (error) {
    console.error('Fetch error:', error);
    return res.status(500).json({ error: '服务器错误' });
  }
};
