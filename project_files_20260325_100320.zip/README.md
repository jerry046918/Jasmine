# 试用期管理体验调研 - 部署指南

## 项目结构

```
├── survey.html      # 问卷页面
├── admin.html       # 数据管理后台
├── api/
│   ├── submit.js    # 提交问卷接口
│   └── responses.js # 获取数据接口
└── vercel.json      # Vercel 配置
```

## 部署步骤

### 1. 准备 Vercel 账号
- 访问 https://vercel.com
- 用 GitHub 账号登录

### 2. 创建项目
```bash
# 安装 Vercel CLI
npm i -g vercel

# 登录
vercel login

# 部署
vercel
```

### 3. 添加 Vercel KV 存储
- 在 Vercel Dashboard 进入项目
- 点击 "Storage" → "Connect Store"
- 选择 "Vercel KV"
- 创建新的 KV 数据库并关联

### 4. 设置环境变量
在 Vercel Dashboard → Project Settings → Environment Variables 添加：

```
KV_URL=your_kv_url
KV_REST_API_URL=your_kv_rest_api_url
KV_REST_API_TOKEN=your_kv_rest_api_token
KV_REST_API_READ_ONLY_TOKEN=your_kv_readonly_token
ADMIN_PASSWORD=your_admin_password  # 管理后台密码
```

### 5. 重新部署
```bash
vercel --prod
```

## 访问地址

- 问卷页面：`https://your-project.vercel.app`
- 管理后台：`https://your-project.vercel.app/admin`

## 本地开发

```bash
# 安装依赖
npm install

# 启动开发服务器
vercel dev
```
