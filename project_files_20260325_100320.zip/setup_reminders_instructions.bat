@echo off
echo 设置定时提醒任务
echo 此脚本需要配合Windows任务计划程序使用
echo.
echo 以下是创建任务计划的步骤：
echo.
echo 1. 按 Win+R 键，输入 taskschd.msc 并按回车
echo 2. 在右侧操作面板中，点击"创建基本任务"
echo 3. 输入任务名称："邮件提醒"
echo 4. 选择触发器："每天"
echo 5. 设置开始时间为：明天上午9:00
echo 6. 操作选择："启动程序"
echo 7. 程序位置：填写 msg.exe
echo 8. 参数：* "现在是早上9点，请记得发邮件"
echo 9. 完成设置
echo.
echo 重复以上步骤为数据分析创建任务：
echo 1. 任务名称："数据分析提醒"
echo 2. 触发器："每天"
echo 3. 设置开始时间为：明天上午10:00
echo 4. 操作："启动程序"
echo 5. 程序位置：msg.exe
echo 6. 参数：* "现在是早上10点，请记得做数据分析"
echo.
echo 注意：如果msg.exe不可用，可以使用其他通知程序或替换为打开一个记事本文件
pause