' 创建自我介绍 PPT - 简约商务风格
' 使用 PowerPoint COM 对象 - VBScript

Option Explicit

Dim powerPoint, presentation, slide
Dim bg, header, title, subtitle, content
Dim cardWidth, cardHeight, gap, x, y, i
Dim outputPath

On Error Resume Next

' 创建 PowerPoint 应用对象
Set powerPoint = CreateObject("PowerPoint.Application")
powerPoint.Visible = False

If Err.Number <> 0 Then
    WScript.Echo "Error creating PowerPoint: " & Err.Description
    WScript.Quit 1
End If

WScript.Echo "Starting PPT creation..."

' 创建新的演示文稿
Set presentation = powerPoint.Presentations.Add

' 设置宽屏 16:9
presentation.PageSetup.SlideWidth = 960
presentation.PageSetup.SlideHeight = 540

' 添加标题页
WScript.Echo "Creating cover slide..."
Set slide = presentation.Slides.Add(1, 12)  ' ppLayoutBlank

' 添加蓝色背景 (RGB: 30, 58, 138)
Set bg = slide.Shapes.AddShape(1, 0, 0, 960, 540)  ' msoShapeRectangle
bg.Fill.ForeColor.RGB = RGB(30, 58, 138)
bg.Line.Visible = 0

' 添加标题
Set title = slide.Shapes.AddTextbox(1, 50, 150, 860, 100)
title.TextFrame.TextRange.Text = "自我介绍"
title.TextFrame.TextRange.Font.Size = 54
title.TextFrame.TextRange.Font.Bold = 1
title.TextFrame.TextRange.Font.Color.RGB = RGB(255, 255, 255)
title.TextFrame.TextRange.ParagraphFormat.Alignment = 2  ' ppAlignCenter

' 添加副标题
Set subtitle = slide.Shapes.AddTextbox(1, 50, 250, 860, 80)
subtitle.TextFrame.TextRange.Text = "Personal Introduction"
subtitle.TextFrame.TextRange.Font.Size = 28
subtitle.TextFrame.TextRange.Font.Color.RGB = RGB(219, 234, 254)
subtitle.TextFrame.TextRange.ParagraphFormat.Alignment = 2

' 添加个人概况页
WScript.Echo "Creating profile slide..."
Set slide = presentation.Slides.Add(2, 12)

Set header = slide.Shapes.AddShape(1, 0, 0, 960, 70)
header.Fill.ForeColor.RGB = RGB(30, 58, 138)
header.Line.Visible = 0

Set title = slide.Shapes.AddTextbox(1, 40, 15, 400, 50)
title.TextFrame.TextRange.Text = "个人概况"
title.TextFrame.TextRange.Font.Size = 32
title.TextFrame.TextRange.Font.Bold = 1
title.TextFrame.TextRange.Font.Color.RGB = RGB(255, 255, 255)

Set content = slide.Shapes.AddTextbox(1, 40, 90, 880, 400)
content.TextFrame.TextRange.Text = "姓名：[您的姓名]" & vbCrLf & _
    "联系电话：[您的电话号码]" & vbCrLf & _
    "电子邮箱：[您的邮箱地址]" & vbCrLf & _
    "所在城市：[您所在的城市]" & vbCrLf & vbCrLf & _
    "个人标签：" & vbCrLf & _
    "  - 积极进取 | 团队协作 | 创新思维" & vbCrLf & _
    "  - 学习能力强 | 责任心强 | 执行力高" & vbCrLf & vbCrLf & _
    "自我介绍：" & vbCrLf & _
    "  简洁有力的个人简介，突出核心优势和职业特点..."
content.TextFrame.TextRange.Font.Size = 18
content.TextFrame.TextRange.Font.Color.RGB = RGB(55, 65, 81)

' 添加教育背景页
WScript.Echo "Creating education slide..."
Set slide = presentation.Slides.Add(3, 12)

Set header = slide.Shapes.AddShape(1, 0, 0, 960, 70)
header.Fill.ForeColor.RGB = RGB(30, 58, 138)
header.Line.Visible = 0

Set title = slide.Shapes.AddTextbox(1, 40, 15, 400, 50)
title.TextFrame.TextRange.Text = "教育背景"
title.TextFrame.TextRange.Font.Size = 32
title.TextFrame.TextRange.Font.Bold = 1
title.TextFrame.TextRange.Font.Color.RGB = RGB(255, 255, 255)

Set content = slide.Shapes.AddTextbox(1, 40, 90, 880, 400)
content.TextFrame.TextRange.Text = "[最高学历] | [学校名称] | [专业名称] | [入学年份]-[毕业年份]" & vbCrLf & _
    "  主修课程：[核心课程列表]" & vbCrLf & _
    "  GPA：[如果优秀可填写]" & vbCrLf & vbCrLf & _
    "[本科学历] | [学校名称] | [专业名称] | [入学年份]-[毕业年份]" & vbCrLf & _
    "  主修课程：[核心课程列表]" & vbCrLf & vbCrLf & _
    "校园荣誉：" & vbCrLf & _
    "  - [奖学金/荣誉称号等]" & vbCrLf & _
    "  - [校园活动/社团经历]"
content.TextFrame.TextRange.Font.Size = 18
content.TextFrame.TextRange.Font.Color.RGB = RGB(55, 65, 81)

' 添加工作经历页
WScript.Echo "Creating work experience slide..."
Set slide = presentation.Slides.Add(4, 12)

Set header = slide.Shapes.AddShape(1, 0, 0, 960, 70)
header.Fill.ForeColor.RGB = RGB(30, 58, 138)
header.Line.Visible = 0

Set title = slide.Shapes.AddTextbox(1, 40, 15, 400, 50)
title.TextFrame.TextRange.Text = "工作经历"
title.TextFrame.TextRange.Font.Size = 32
title.TextFrame.TextRange.Font.Bold = 1
title.TextFrame.TextRange.Font.Color.RGB = RGB(255, 255, 255)

Set content = slide.Shapes.AddTextbox(1, 40, 90, 880, 400)
content.TextFrame.TextRange.Text = "[最近公司] | [职位名称] | [入职时间]-[至今/离职时间]" & vbCrLf & _
    "  - 主要职责：[工作职责描述]" & vbCrLf & _
    "  - 核心成就：[工作成果]" & vbCrLf & vbCrLf & _
    "[前公司] | [职位名称] | [入职时间]-[离职时间]" & vbCrLf & _
    "  - 主要职责：[工作职责描述]" & vbCrLf & _
    "  - 核心成就：[工作成果]" & vbCrLf & vbCrLf & _
    "[更早公司] | [职位名称] | [入职时间]-[离职时间]" & vbCrLf & _
    "  - 主要职责：[工作职责描述]"
content.TextFrame.TextRange.Font.Size = 18
content.TextFrame.TextRange.Font.Color.RGB = RGB(55, 65, 81)

' 添加项目经验页
WScript.Echo "Creating project experience slide..."
Set slide = presentation.Slides.Add(5, 12)

Set header = slide.Shapes.AddShape(1, 0, 0, 960, 70)
header.Fill.ForeColor.RGB = RGB(30, 58, 138)
header.Line.Visible = 0

Set title = slide.Shapes.AddTextbox(1, 40, 15, 400, 50)
title.TextFrame.TextRange.Text = "项目经验"
title.TextFrame.TextRange.Font.Size = 32
title.TextFrame.TextRange.Font.Bold = 1
title.TextFrame.TextRange.Font.Color.RGB = RGB(255, 255, 255)

' 添加项目卡片
cardWidth = 420
cardHeight = 150
gap = 30

Dim project1, project2, project3, project4
Set project1 = slide.Shapes.AddShape(7, 40, 90, cardWidth, cardHeight)  ' msoShapeRoundedRectangle
project1.Fill.ForeColor.RGB = RGB(219, 234, 254)
project1.Line.Visible = 0
project1.TextFrame.TextRange.Text = "[项目名称 1]" & vbCrLf & "角色：[项目角色]" & vbCrLf & "成果：[项目成果/数据]"
project1.TextFrame.TextRange.Font.Size = 16
project1.TextFrame.TextRange.Font.Color.RGB = RGB(55, 65, 81)

Set project2 = slide.Shapes.AddShape(7, 490, 90, cardWidth, cardHeight)
project2.Fill.ForeColor.RGB = RGB(219, 234, 254)
project2.Line.Visible = 0
project2.TextFrame.TextRange.Text = "[项目名称 2]" & vbCrLf & "角色：[项目角色]" & vbCrLf & "成果：[项目成果/数据]"
project2.TextFrame.TextRange.Font.Size = 16
project2.TextFrame.TextRange.Font.Color.RGB = RGB(55, 65, 81)

Set project3 = slide.Shapes.AddShape(7, 40, 270, cardWidth, cardHeight)
project3.Fill.ForeColor.RGB = RGB(219, 234, 254)
project3.Line.Visible = 0
project3.TextFrame.TextRange.Text = "[项目名称 3]" & vbCrLf & "角色：[项目角色]" & vbCrLf & "成果：[项目成果/数据]"
project3.TextFrame.TextRange.Font.Size = 16
project3.TextFrame.TextRange.Font.Color.RGB = RGB(55, 65, 81)

Set project4 = slide.Shapes.AddShape(7, 490, 270, cardWidth, cardHeight)
project4.Fill.ForeColor.RGB = RGB(219, 234, 254)
project4.Line.Visible = 0
project4.TextFrame.TextRange.Text = "[项目名称 4]" & vbCrLf & "角色：[项目角色]" & vbCrLf & "成果：[项目成果/数据]"
project4.TextFrame.TextRange.Font.Size = 16
project4.TextFrame.TextRange.Font.Color.RGB = RGB(55, 65, 81)

' 添加专业技能页
WScript.Echo "Creating skills slide..."
Set slide = presentation.Slides.Add(6, 12)

Set header = slide.Shapes.AddShape(1, 0, 0, 960, 70)
header.Fill.ForeColor.RGB = RGB(30, 58, 138)
header.Line.Visible = 0

Set title = slide.Shapes.AddTextbox(1, 40, 15, 400, 50)
title.TextFrame.TextRange.Text = "专业技能"
title.TextFrame.TextRange.Font.Size = 32
title.TextFrame.TextRange.Font.Bold = 1
title.TextFrame.TextRange.Font.Color.RGB = RGB(255, 255, 255)

Dim skillNames, skillLevels, skillName, barBg, bar, barWidth, percent
skillNames = Array("专业技能 1", "专业技能 2", "专业技能 3", "专业技能 4", "语言/工具", "软技能")
skillLevels = Array(90, 85, 80, 75, 85, 90)

For i = 0 To 5
    y = 90 + i * 50

    Set skillName = slide.Shapes.AddTextbox(1, 40, y, 200, 40)
    skillName.TextFrame.TextRange.Text = skillNames(i)
    skillName.TextFrame.TextRange.Font.Size = 16
    skillName.TextFrame.TextRange.Font.Bold = 1
    skillName.TextFrame.TextRange.Font.Color.RGB = RGB(55, 65, 81)

    Set barBg = slide.Shapes.AddShape(1, 250, y + 10, 500, 20)
    barBg.Fill.ForeColor.RGB = RGB(243, 244, 246)
    barBg.Line.Visible = 0

    barWidth = 500 * skillLevels(i) / 100
    Set bar = slide.Shapes.AddShape(1, 250, y + 10, barWidth, 20)
    bar.Fill.ForeColor.RGB = RGB(59, 130, 246)
    bar.Line.Visible = 0

    Set percent = slide.Shapes.AddTextbox(1, 760, y, 100, 40)
    percent.TextFrame.TextRange.Text = skillLevels(i) & "%"
    percent.TextFrame.TextRange.Font.Size = 14
    percent.TextFrame.TextRange.Font.Color.RGB = RGB(107, 114, 128)
Next

' 添加荣誉证书页
WScript.Echo "Creating certificates slide..."
Set slide = presentation.Slides.Add(7, 12)

Set header = slide.Shapes.AddShape(1, 0, 0, 960, 70)
header.Fill.ForeColor.RGB = RGB(30, 58, 138)
header.Line.Visible = 0

Set title = slide.Shapes.AddTextbox(1, 40, 15, 400, 50)
title.TextFrame.TextRange.Text = "荣誉证书"
title.TextFrame.TextRange.Font.Size = 32
title.TextFrame.TextRange.Font.Bold = 1
title.TextFrame.TextRange.Font.Color.RGB = RGB(255, 255, 255)

Set content = slide.Shapes.AddTextbox(1, 40, 90, 880, 400)
content.TextFrame.TextRange.Text = "专业认证：" & vbCrLf & _
    "  - [证书名称 1] | [颁发机构] | [获得时间]" & vbCrLf & _
    "  - [证书名称 2] | [颁发机构] | [获得时间]" & vbCrLf & _
    "  - [证书名称 3] | [颁发机构] | [获得时间]" & vbCrLf & vbCrLf & _
    "荣誉奖项：" & vbCrLf & _
    "  - [奖项名称 1] | [颁发单位] | [获得时间]" & vbCrLf & _
    "  - [奖项名称 2] | [颁发单位] | [获得时间]" & vbCrLf & vbCrLf & _
    "其他资质：" & vbCrLf & _
    "  - [资质证书/语言能力等]"
content.TextFrame.TextRange.Font.Size = 18
content.TextFrame.TextRange.Font.Color.RGB = RGB(55, 65, 81)

' 添加兴趣爱好页
WScript.Echo "Creating hobbies slide..."
Set slide = presentation.Slides.Add(8, 12)

Set header = slide.Shapes.AddShape(1, 0, 0, 960, 70)
header.Fill.ForeColor.RGB = RGB(30, 58, 138)
header.Line.Visible = 0

Set title = slide.Shapes.AddTextbox(1, 40, 15, 400, 50)
title.TextFrame.TextRange.Text = "兴趣爱好"
title.TextFrame.TextRange.Font.Size = 32
title.TextFrame.TextRange.Font.Bold = 1
title.TextFrame.TextRange.Font.Color.RGB = RGB(255, 255, 255)

Set content = slide.Shapes.AddTextbox(1, 40, 90, 880, 400)
content.TextFrame.TextRange.Text = "运动健身：" & vbCrLf & _
    "  - [运动项目] - 保持健康体魄，培养毅力" & vbCrLf & vbCrLf & _
    "阅读学习：" & vbCrLf & _
    "  - [书籍类型] - 持续学习，拓展知识面" & vbCrLf & vbCrLf & _
    "艺术爱好：" & vbCrLf & _
    "  - [艺术项目] - 培养审美，提升创造力" & vbCrLf & vbCrLf & _
    "社会实践：" & vbCrLf & _
    "  - [志愿活动/社团] - 回馈社会，锻炼能力" & vbCrLf & vbCrLf & _
    "个人特长：" & vbCrLf & _
    "  - [特殊技能/才能]"
content.TextFrame.TextRange.Font.Size = 18
content.TextFrame.TextRange.Font.Color.RGB = RGB(55, 65, 81)

' 添加未来规划页
WScript.Echo "Creating future plans slide..."
Set slide = presentation.Slides.Add(9, 12)

Set header = slide.Shapes.AddShape(1, 0, 0, 960, 70)
header.Fill.ForeColor.RGB = RGB(30, 58, 138)
header.Line.Visible = 0

Set title = slide.Shapes.AddTextbox(1, 40, 15, 400, 50)
title.TextFrame.TextRange.Text = "未来规划"
title.TextFrame.TextRange.Font.Size = 32
title.TextFrame.TextRange.Font.Bold = 1
title.TextFrame.TextRange.Font.Color.RGB = RGB(255, 255, 255)

Set content = slide.Shapes.AddTextbox(1, 40, 90, 880, 400)
content.TextFrame.TextRange.Text = "短期目标 (1-2 年)：" & vbCrLf & _
    "  - [具体目标 1] - 提升专业技能" & vbCrLf & _
    "  - [具体目标 2] - 积累项目经验" & vbCrLf & _
    "  - [具体目标 3] - 拓展行业视野" & vbCrLf & vbCrLf & _
    "中期目标 (3-5 年)：" & vbCrLf & _
    "  - [发展方向] - 成为领域专家" & vbCrLf & _
    "  - [能力提升] - 提升管理能力" & vbCrLf & vbCrLf & _
    "长期愿景：" & vbCrLf & _
    "  - [职业愿景] - 实现职业理想" & vbCrLf & _
    "  - [个人价值] - 创造更大价值"
content.TextFrame.TextRange.Font.Size = 18
content.TextFrame.TextRange.Font.Color.RGB = RGB(55, 65, 81)

' 添加结束页
WScript.Echo "Creating ending slide..."
Set slide = presentation.Slides.Add(10, 12)

Set bg = slide.Shapes.AddShape(1, 0, 0, 960, 540)
bg.Fill.ForeColor.RGB = RGB(30, 58, 138)
bg.Line.Visible = 0

Set title = slide.Shapes.AddTextbox(1, 50, 180, 860, 100)
title.TextFrame.TextRange.Text = "感谢聆听"
title.TextFrame.TextRange.Font.Size = 48
title.TextFrame.TextRange.Font.Bold = 1
title.TextFrame.TextRange.Font.Color.RGB = RGB(255, 255, 255)
title.TextFrame.TextRange.ParagraphFormat.Alignment = 2

Set content = slide.Shapes.AddTextbox(1, 50, 280, 860, 80)
content.TextFrame.TextRange.Text = "联系方式：[电话] | [邮箱]" & vbCrLf & "THANK YOU"
content.TextFrame.TextRange.Font.Size = 24
content.TextFrame.TextRange.Font.Color.RGB = RGB(219, 234, 254)
content.TextFrame.TextRange.ParagraphFormat.Alignment = 2

' 保存文件
outputPath = "C:\Users\tangliying\lobsterai\project\self_introduction.pptx"
presentation.SaveAs outputPath, 24  ' ppSaveAsOpenXMLPresentation = 24

WScript.Echo "PPT created successfully! Path: " & outputPath

' 关闭 PowerPoint
presentation.Close
powerPoint.Quit

Set powerPoint = Nothing
Set presentation = Nothing

WScript.Echo "Done!"
