# 定时提醒脚本
# 该脚本将持续运行并在设定的时间发送提醒

param(
    [switch]$RunInBackground
)

# 设置提醒时间 (明天)
$tomorrow = (Get-Date).AddDays(1)

# 提醒1: 明天上午9点 - 发邮件提醒
$reminder1Time = Get-Date -Date "$($tomorrow.ToString('yyyy-MM-dd')) 09:00:00"

# 提醒2: 明天上午10点 - 数据分析提醒  
$reminder2Time = Get-Date -Date "$($tomorrow.ToString('yyyy-MM-dd')) 10:00:00"

Write-Host "定时提醒已启动" -ForegroundColor Green
Write-Host "提醒1: $(Get-Date $reminder1Time -Format 'yyyy-MM-dd HH:mm:ss') - 发邮件提醒"
Write-Host "提醒2: $(Get-Date $reminder2Time -Format 'yyyy-MM-dd HH:mm:ss') - 数据分析提醒"

# 函数：显示提醒
function Show-Reminder {
    param([string]$message)
    
    Write-Host "$(Get-Date -Format 'HH:mm:ss') - $message" -ForegroundColor Yellow
    
    # 如果可能，尝试弹出通知窗口
    try {
        Add-Type -AssemblyName PresentationCore,PresentationFramework
        [System.Windows.MessageBox]::Show($message, "定时提醒", "OK", "Information")
    }
    catch {
        Write-Host "弹窗通知不可用，已在控制台显示提醒" -ForegroundColor Gray
    }
}

# 主循环
$continue = $true
while ($continue) {
    $currentTime = Get-Date
    
    # 检查是否到达第一个提醒时间
    if ($currentTime.Hour -eq $reminder1Time.Hour -and 
        $currentTime.Minute -eq $reminder1Time.Minute -and
        $currentTime.Day -eq $reminder1Time.Day -and
        $currentTime.Month -eq $reminder1Time.Month -and
        $currentTime.Year -eq $reminder1Time.Year) {
        
        Show-Reminder "⏰ 提醒：现在是早上9点，请记得发邮件"
        
        # 等待一分钟以避免重复触发
        Start-Sleep -Seconds 60
    }
    
    # 检查是否到达第二个提醒时间
    if ($currentTime.Hour -eq $reminder2Time.Hour -and 
        $currentTime.Minute -eq $reminder2Time.Minute -and
        $currentTime.Day -eq $reminder2Time.Day -and
        $currentTime.Month -eq $reminder2Time.Month -and
        $currentTime.Year -eq $reminder2Time.Year) {
        
        Show-Reminder "⏰ 提醒：现在是早上10点，请记得做数据分析"
        
        # 等待一分钟以避免重复触发
        Start-Sleep -Seconds 60
    }
    
    # 检查是否已超过所有提醒时间，如果是则退出
    if ($currentTime -gt $reminder2Time.AddMinutes(5)) {  # 添加5分钟缓冲时间
        Write-Host "所有提醒任务已完成，脚本将在30秒后退出" -ForegroundColor Green
        Start-Sleep -Seconds 30
        $continue = $false
    }
    
    Start-Sleep -Seconds 30  # 每30秒检查一次
}

Write-Host "定时提醒服务已结束" -ForegroundColor Green