import pandas as pd
import sys

try:
    # Read Excel file
    df = pd.read_excel(r'C:\Users\tangliying\lobsterai\project\AI 测试数据.xlsx')

    # Display basic info
    print("=== 数据基本信息 ===", file=sys.stderr)
    print(f"数据形状：{df.shape}", file=sys.stderr)
    print(f"\n列名：{df.columns.tolist()}", file=sys.stderr)
    print(f"\n数据类型:\n{df.dtypes}", file=sys.stderr)
    print(f"\n前 10 行数据:", file=sys.stderr)
    print(df.head(10).to_string(), file=sys.stderr)

    # Save to CSV for inspection
    df.to_csv(r'C:\Users\tangliying\lobsterai\project\data_preview.csv', index=False, encoding='utf-8-sig')
    print("\n数据预览已保存到 data_preview.csv", file=sys.stderr)
except Exception as e:
    print(f"Error: {e}", file=sys.stderr)
    import traceback
    traceback.print_exc()
