# 抽奖小工具 - PowerShell版本

# 创建参与者数组
$participants = @()

# 添加参与者函数
function Add-Participant {
    param([string]$Name)
    if ($Name -ne "") {
        $script:participants += $Name
        Write-Host "已添加参与者: $Name" -ForegroundColor Green
    } else {
        Write-Host "姓名不能为空!" -ForegroundColor Red
    }
}

# 显示所有参与者
function Show-Participants {
    if ($participants.Count -eq 0) {
        Write-Host "暂无参与者" -ForegroundColor Yellow
        return
    }
    
    Write-Host "当前共有 $($participants.Count) 名参与者:" -ForegroundColor Cyan
    for ($i = 0; $i -lt $participants.Count; $i++) {
        Write-Host "$($i + 1). $($participants[$i])"
    }
}

# 抽奖函数
function Start-Lottery {
    param([int]$Count = 1)
    
    if ($participants.Count -lt $Count) {
        Write-Host "参与者数量不足，无法抽取 $Count 名获奖者" -ForegroundColor Red
        return
    }
    
    Write-Host "`n🎉 开始抽奖..." -ForegroundColor Magenta
    Start-Sleep -Milliseconds 1000
    
    Write-Host "抽奖中" -NoNewline -ForegroundColor Yellow
    for ($i = 0; $i -lt 3; $i++) {
        Start-Sleep -Milliseconds 500
        Write-Host "." -NoNewline -ForegroundColor Yellow
    }
    Write-Host ""
    
    # 随机抽取获奖者
    $winners = @()
    $tempParticipants = $participants.Clone()
    
    for ($i = 0; $i -lt $Count; $i++) {
        $randomIndex = Get-Random -Minimum 0 -Maximum $tempParticipants.Count
        $winners += $tempParticipants[$randomIndex]
        # 移除已抽中的参与者，避免重复中奖
        $tempParticipants = $tempParticipants | Where-Object { $_ -ne $tempParticipants[$randomIndex] }
    }
    
    Write-Host "`n🏆 抽奖结果:" -ForegroundColor Green
    for ($i = 0; $i -lt $winners.Count; $i++) {
        Write-Host "第$($i + 1)名获奖者: $($winners[$i])" -ForegroundColor Yellow
    }
    
    # 从主列表中移除获奖者
    foreach ($winner in $winners) {
        $script:participants = $script:participants | Where-Object { $_ -ne $winner }
    }
    
    return $winners
}

# 主程序循环
Write-Host "=" * 50 -ForegroundColor Blue
Write-Host "🎰 欢迎使用抽奖小工具!" -ForegroundColor Blue
Write-Host "=" * 50 -ForegroundColor Blue

while ($true) {
    Write-Host ""
    Write-Host "请选择操作:" -ForegroundColor Cyan
    Write-Host "1. 添加参与者"
    Write-Host "2. 显示所有参与者"
    Write-Host "3. 抽奖"
    Write-Host "4. 移除参与者"
    Write-Host "5. 重置参与者列表"
    Write-Host "0. 退出"
    
    $choice = Read-Host "`n请输入选项 (0-5)"
    
    switch ($choice) {
        "1" {
            $name = Read-Host "请输入参与者姓名"
            Add-Participant $name
        }
        "2" {
            Show-Participants
        }
        "3" {
            $countInput = Read-Host "请输入要抽取的人数 (默认为1)"
            $count = if ($countInput -match "^\d+$") { [int]$countInput } else { 1 }
            if ($count -gt 0) {
                Start-Lottery $count
            } else {
                Write-Host "抽取人数必须大于0!" -ForegroundColor Red
            }
        }
        "4" {
            if ($participants.Count -eq 0) {
                Write-Host "暂无参与者可移除" -ForegroundColor Yellow
            } else {
                Show-Participants
                $index = Read-Host "请输入要移除的参与者序号"
                if ($index -match "^\d+$") {
                    $indexNum = [int]$index - 1
                    if ($indexNum -ge 0 -and $indexNum -lt $participants.Count) {
                        $removedName = $participants[$indexNum]
                        $script:participants = $participants | Where-Object { $_ -ne $removedName }
                        Write-Host "已移除参与者: $removedName" -ForegroundColor Green
                    } else {
                        Write-Host "无效的序号!" -ForegroundColor Red
                    }
                } else {
                    Write-Host "请输入有效的数字!" -ForegroundColor Red
                }
            }
        }
        "5" {
            $confirm = Read-Host "确定要重置参与者列表吗? (y/N)"
            if ($confirm -eq "y" -or $confirm -eq "Y") {
                $script:participants = @()
                Write-Host "已重置参与者列表" -ForegroundColor Green
            }
        }
        "0" {
            Write-Host "感谢使用抽奖小工具，再见! 👋" -ForegroundColor Green
            break
        }
        default {
            Write-Host "无效选项，请重新选择!" -ForegroundColor Red
        }
    }
}