import pandas as pd

df = pd.read_excel('survey.xlsx')

# 保存基本信息
with open('survey_info.txt', 'w', encoding='utf-8') as f:
    f.write(f"总记录数: {len(df)}\n")
    f.write(f"总问题数: {len(df.columns)}\n\n")
    f.write("问题列表:\n")
    for i, col in enumerate(df.columns, 1):
        f.write(f"{i}. {col}\n")
    
    f.write("\n=== 样本数据 (前3行) ===\n")
    f.write(df.head(3).to_string())
    
    f.write("\n\n=== 各问题回答统计 ===\n")
    for col in df.columns:
        f.write(f"\n【{col}】\n")
        vc = df[col].value_counts().head(5)
        for val, count in vc.items():
            f.write(f"  {val}: {count}\n")

print("OK")
