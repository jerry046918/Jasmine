' VBS script to create a Word document from a text file
Dim objWord, objDoc, objSelection, objFSO, objFile
Dim strInputFile, strOutputFile, strLine, strContent

strInputFile = "C:\Users\tangliying\lobsterai\project\私域平台调研问卷分析报告.txt"
strOutputFile = "C:\Users\tangliying\lobsterai\project\私域平台调研问卷分析报告.docx"

' Check if input file exists
Set objFSO = CreateObject("Scripting.FileSystemObject")
If Not objFSO.FileExists(strInputFile) Then
    WScript.Echo "错误：找不到源文件 " & strInputFile
    WScript.Quit(1)
End If

' Create Word application object
Set objWord = CreateObject("Word.Application")
objWord.Visible = False

' Create a new document
Set objDoc = objWord.Documents.Add()
Set objSelection = objWord.Selection

' Read the content of the text file
Set objFile = objFSO.OpenTextFile(strInputFile, 1, False, -1) ' -1 indicates Unicode
strContent = objFile.ReadAll
objFile.Close

' Split content by lines and add to document
arrLines = Split(strContent, vbCrLf)

For i = 0 To UBound(arrLines)
    strLine = Trim(arrLines(i))
    
    ' Skip empty lines
    If strLine <> "" Then
        ' Add the line to the document
        objSelection.TypeText strLine
        objSelection.TypeParagraph
        
        ' Simple heading detection
        If Left(strLine, 1) = "一" Or Left(strLine, 1) = "二" Or Left(strLine, 1) = "三" Or _
           Left(strLine, 1) = "四" Or Left(strLine, 1) = "五" Or Left(strLine, 1) = "1" Or _
           Left(strLine, 1) = "2" Or Left(strLine, 1) = "3" Or Left(strLine, 1) = "4" Then
            
            ' Apply heading style (move selection back to this paragraph and apply style)
            objSelection.MoveUp 2 ' Move up to the paragraph we just added
            objSelection.Range.Style = objWord.ActiveDocument.Styles("Heading 1")
        End If
    Else
        ' Add paragraph break for empty lines
        objSelection.TypeParagraph
    End If
Next

' Save the document
objDoc.SaveAs2 strOutputFile ' For newer Word versions
' For older Word versions, use: objDoc.SaveAs strOutputFile
WScript.Echo "文档已成功创建: " & strOutputFile

' Clean up
objDoc.Close
objWord.Quit

Set objSelection = Nothing
Set objDoc = Nothing
Set objWord = Nothing
Set objFile = Nothing
Set objFSO = Nothing