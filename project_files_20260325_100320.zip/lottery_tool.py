import random
import time

class LotteryTool:
    def __init__(self):
        self.participants = []
    
    def add_participant(self, name):
        """添加参与者"""
        self.participants.append(name)
        print(f"已添加参与者: {name}")
    
    def add_multiple_participants(self, names):
        """批量添加参与者"""
        for name in names:
            self.participants.append(name)
            print(f"已添加参与者: {name}")
    
    def remove_participant(self, name):
        """移除参与者"""
        if name in self.participants:
            self.participants.remove(name)
            print(f"已移除参与者: {name}")
        else:
            print(f"未找到参与者: {name}")
    
    def show_participants(self):
        """显示所有参与者"""
        if not self.participants:
            print("暂无参与者")
            return
        
        print(f"当前共有 {len(self.participants)} 名参与者:")
        for i, name in enumerate(self.participants, 1):
            print(f"{i}. {name}")
    
    def draw_winner(self, count=1):
        """抽取获胜者"""
        if len(self.participants) < count:
            print(f"参与者数量不足，无法抽取 {count} 名获奖者")
            return []
        
        winners = random.sample(self.participants, count)
        
        print("\n🎉 开始抽奖...")
        time.sleep(1)
        print("抽奖中", end="", flush=True)
        for _ in range(3):
            time.sleep(0.5)
            print(".", end="", flush=True)
        print()
        
        print(f"\n🏆 抽奖结果:")
        for i, winner in enumerate(winners, 1):
            print(f"第{i}名获奖者: {winner}")
        
        # 从参与者列表中移除获奖者（可选）
        for winner in winners:
            self.participants.remove(winner)
        
        return winners
    
    def reset(self):
        """重置参与者列表"""
        self.participants = []
        print("已重置参与者列表")

def main():
    lottery = LotteryTool()
    
    print("=" * 50)
    print("🎰 欢迎使用抽奖小工具!")
    print("=" * 50)
    
    while True:
        print("\n请选择操作:")
        print("1. 添加参与者")
        print("2. 批量添加参与者")
        print("3. 移除参与者")
        print("4. 显示所有参与者")
        print("5. 抽奖")
        print("6. 重置参与者列表")
        print("0. 退出")
        
        try:
            choice = input("\n请输入选项 (0-6): ").strip()
            
            if choice == "1":
                name = input("请输入参与者姓名: ").strip()
                if name:
                    lottery.add_participant(name)
                else:
                    print("姓名不能为空!")
            
            elif choice == "2":
                names_input = input("请输入多个参与者姓名，用逗号分隔: ").strip()
                if names_input:
                    names = [name.strip() for name in names_input.split(",")]
                    lottery.add_multiple_participants(names)
                else:
                    print("姓名列表不能为空!")
            
            elif choice == "3":
                name = input("请输入要移除的参与者姓名: ").strip()
                if name:
                    lottery.remove_participant(name)
                else:
                    print("姓名不能为空!")
            
            elif choice == "4":
                lottery.show_participants()
            
            elif choice == "5":
                count_input = input("请输入要抽取的人数 (默认为1): ").strip()
                count = int(count_input) if count_input.isdigit() else 1
                if count > 0:
                    lottery.draw_winner(count)
                else:
                    print("抽取人数必须大于0!")
            
            elif choice == "6":
                confirm = input("确定要重置参与者列表吗? (y/N): ").strip().lower()
                if confirm == "y":
                    lottery.reset()
            
            elif choice == "0":
                print("感谢使用抽奖小工具，再见! 👋")
                break
            
            else:
                print("无效选项，请重新选择!")
        
        except KeyboardInterrupt:
            print("\n\n程序被中断，再见! 👋")
            break
        except Exception as e:
            print(f"发生错误: {e}")

if __name__ == "__main__":
    main()