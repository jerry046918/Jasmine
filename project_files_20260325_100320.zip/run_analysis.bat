@echo off
chcp 65001 >nul
cd /d C:\Users\tangliying\lobsterai\project
python full_analysis.py
pause
