Option Explicit

Dim excelApp, workbook, worksheet, usedRange
Dim rows, cols, r, c
Dim colNames(), rowData()

' 创建 Excel 应用
Set excelApp = CreateObject("Excel.Application")
excelApp.Visible = False
excelApp.DisplayAlerts = False

' 打开工作簿
Set workbook = excelApp.Workbooks.Open("C:\Users\tangliying\lobsterai\project\AI 测试数据.xlsx")
Set worksheet = workbook.Worksheets(1)

' 获取已使用的范围
rows = worksheet.UsedRange.Rows.Count
cols = worksheet.UsedRange.Columns.Count

' 输出列名
WScript.Echo "=== 列名 ==="
For c = 1 To cols
    WScript.Echo "列 " & c & ": " & worksheet.Cells(1, c).Text
Next

' 输出前 10 行数据
WScript.Echo ""
WScript.Echo "=== 前 10 行数据 ==="
For r = 1 To 10
    If r > rows Then Exit For
    rowData = Array()
    For c = 1 To cols
        ReDim Preserve rowData(UBound(rowData) + 1)
        rowData(UBound(rowData)) = worksheet.Cells(r, c).Text
    Next
    WScript.Echo "行 " & r & ": " & Join(rowData, " | ")
Next

' 关闭
workbook.Close False
excelApp.Quit

Set workbook = Nothing
Set excelApp = Nothing

WScript.Echo ""
WScript.Echo "完成！"
