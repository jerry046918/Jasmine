import pandas as pd
import json

# 读取Excel文件
df = pd.read_excel('survey.xlsx')

# 构建分析结果
result = {
    "基本信息": {
        "总记录数": len(df),
        "总问题数": len(df.columns)
    },
    "问题列表": [str(col) for col in df.columns],
    "样本数据": df.head(3).to_dict(orient='records'),
    "数据完整性": {},
    "回答分布": {}
}

# 数据完整性
for col in df.columns:
    missing = df[col].isnull().sum()
    result["数据完整性"][str(col)] = {
        "有效回答": int(len(df) - missing),
        "缺失": int(missing),
        "完整率": f"{((len(df) - missing) / len(df) * 100):.1f}%"
    }

# 各问题回答分布
for col in df.columns:
    value_counts = df[col].value_counts().head(10)
    result["回答分布"][str(col)] = {
        "唯一值数量": int(df[col].nunique()),
        "分布": {str(k): int(v) for k, v in value_counts.items()}
    }

# 保存为JSON
with open('survey_analysis.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)

print("分析完成！")
