@echo off
setlocal enabledelayedexpansion

title Lottery Tool

REM Initialize variables
set count=0
set max_participants=100

:menu
cls
echo ========================================
echo         Lottery Tool
echo ========================================
echo.
echo Number of participants: %count%
echo.
echo Options:
echo 1. Add participant
echo 2. Show participants
echo 3. Draw lottery
echo 4. Clear list
echo 0. Exit
echo.
set /p option=Enter option (0-4): 

if "%option%"=="1" goto add_participant
if "%option%"=="2" goto show_participants
if "%option%"=="3" goto draw_lottery
if "%option%"=="4" goto clear_list
if "%option%"=="0" goto exit_program
echo Invalid option!
pause
goto menu

:add_participant
cls
set /p name=Enter participant name: 
if not "%name%"=="" (
    set participant_!count!=%name%
    set /a count+=1
    echo Added: %name%
) else (
    echo Name cannot be empty!
)
pause
goto menu

:show_participants
cls
echo.
echo Participant List:
if %count%==0 (
    echo No participants
) else (
    for /l %%i in (0,1,%count%) do (
        if defined participant_%%i (
            echo %%i. !participant_%%i!
        )
    )
)
pause
goto menu

:draw_lottery
if %count%==0 (
    echo No participants to draw from!
    pause
    goto menu
)
set /p draw_count=Enter number of winners (default 1): 
if "%draw_count%"=="" set draw_count=1
if %draw_count% gtr %count% (
    echo Not enough participants!
    pause
    goto menu
)

cls
echo.
echo Drawing lottery...
ping localhost -n 2 > nul
echo.
echo Winners:
set temp_count=%count%
set win_counter=0

:draw_loop
if %win_counter% geq %draw_count% goto draw_done

REM Generate random number
set /a rand_num=!random! %% !temp_count!

REM Find the participant at the random position
set current_index=-1
set search_pos=0
:find_loop
set /a current_index+=1
if "!participant_!current_index!!"=="" goto find_loop
if !search_pos! lss !rand_num! (
    set /a search_pos+=1
    goto find_loop
)

REM We found our winner
set winner=!participant_!current_index!!
echo Winner !win_counter!: !winner!

REM Mark this participant as drawn by clearing their name
set participant_!current_index!=

set /a win_counter+=1
set /a temp_count-=1
if %win_counter% lss %draw_count% goto draw_loop

:draw_done
echo Drawing completed!
pause
goto menu

:clear_list
set count=0
for /l %%i in (0,1,%max_participants%) do (
    set participant_%%i=
)
echo Participant list cleared
pause
goto menu

:exit_program
echo Thank you for using the lottery tool!
pause