@echo off
setlocal enabledelayedexpansion

REM 抽奖小工具 - 批处理版本
title 抽奖小工具

REM 初始化变量
set count=0
set winner_count=0

:menu
cls
echo ========================================
echo         欢迎使用抽奖小工具!
echo ========================================
echo.
echo 当前参与者数量：%count%
echo.
echo 请选择操作:
echo 1. 添加参与者
echo 2. 显示所有参与者
echo 3. 抽奖
echo 4. 清空参与者列表
echo 0. 退出
echo.
set /p option=请输入选项 (0-4):

if "%option%"=="1" goto add_participant
if "%option%"=="2" goto show_participants
if "%option%"=="3" goto draw_lottery
if "%option%"=="4" goto clear_list
if "%option%"=="0" goto exit_program
echo 无效选项，请重新选择!
pause
goto menu

:add_participant
cls
set /p name=请输入参与者姓名: 
if not "%name%"=="" (
    set participant_!count!=%name%
    set /a count+=1
    echo 已添加参与者: %name%
) else (
    echo 姓名不能为空!
)
pause
goto menu

:show_participants
cls
echo.
echo 当前参与者列表:
if %count%==0 (
    echo 暂无参与者
) else (
    for /l %%i in (0,1,%count%) do (
        if defined participant_%%i (
            echo %%i. !participant_%%i!
        )
    )
)
pause
goto menu

:draw_lottery
if %count%==0 (
    echo 没有参与者，无法抽奖！
    pause
    goto menu
)
set /p draw_count=请输入要抽取的人数 (默认为1): 
if "%draw_count%"=="" set draw_count=1
if %draw_count% gtr %count% (
    echo 参与者数量不足，无法抽取 %draw_count% 名获奖者
    pause
    goto menu
)

cls
echo.
echo 正在抽奖...
ping localhost -n 3 > nul
echo.
echo 抽奖结果:
set temp_count=%count%
set win_counter=0

:draw_loop
if %win_counter% geq %draw_count% goto draw_done
set /a rand_num=!random! %% !temp_count!
set current_index=0
set found_index=0

:find_participant
if "!participant_!current_index!!"=="" (
    set /a current_index+=1
    goto find_participant
)
if !found_index!==!rand_num! (
    set winner=!participant_!current_index!!
    if defined winner (
        set /a win_counter+=1
        echo 第!win_counter!名获奖者: !winner!
        set participant_!current_index!=
        set /a temp_count-=1
    )
) else (
    set /a found_index+=1
    set /a current_index+=1
    if !current_index! lss 100 goto find_participant
)
goto draw_loop

:draw_done
echo 抽奖完成！
pause
goto menu

:clear_list
set count=0
for /l %%i in (0,1,99) do (
    set participant_%%i=
)
echo 已清空参与者列表
pause
goto menu

:exit_program
echo 感谢使用抽奖小工具，再见!
pause