# -*- coding: utf-8 -*-
"""
Excel 数据分类汇总分析脚本 - 完整版
"""

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.chart import BarChart, Reference, PieChart
from openpyxl.utils.dataframe import dataframe_to_rows
import numpy as np

# 文件路径
input_file = r'C:\Users\tangliying\lobsterai\project\AI 测试数据.xlsx'
output_file = r'C:\Users\tangliying\lobsterai\project\汇总统计结果.xlsx'

print("=== 开始读取数据 ===")

# 读取 Excel 文件
df = pd.read_excel(input_file)
print(f"数据形状：{df.shape}")
print(f"列名：{df.columns.tolist()}")

# 尝试识别列
# 查找分类列（包含"分类"或"L3"）
category_cols = [col for col in df.columns if '分类' in col or 'L3' in col or 'L2' in col or 'L1' in col]
print(f"\n分类列：{category_cols}")

# 查找标准工时列
std_time_cols = [col for col in df.columns if '工时' in col or '时间' in col or '时长' in col or '标准' in col]
print(f"标准工时列候选：{std_time_cols}")

# 查找业务量列
volume_cols = [col for col in df.columns if '业务量' in col or '数量' in col or '单量' in col or '件' in col or '票数' in col]
print(f"业务量列候选：{volume_cols}")

# 查找数值列
numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
print(f"数值列：{numeric_cols}")

# 确定要使用的列
# 使用第一个分类列作为主要分类
if category_cols:
    category_col = category_cols[0]  # 如"分类 2 L3"
    print(f"\n使用分类列：{category_col}")
else:
    category_col = None
    print("\n警告：未找到分类列")

# 使用第一个标准工时列
std_time_col = None
for col in std_time_cols:
    if '标准' in col or '工时' in col:
        std_time_col = col
        break
if std_time_col is None and std_time_cols:
    std_time_col = std_time_cols[0]
print(f"使用标准工时列：{std_time_col}")

# 使用第一个业务量列
volume_col = None
for col in volume_cols:
    if '业务量' in col or '数量' in col:
        volume_col = col
        break
if volume_col is None and volume_cols:
    volume_col = volume_cols[0]
print(f"使用业务量列：{volume_col}")

# 创建输出 Excel 文件
wb = Workbook()
ws = wb.active
ws.title = "汇总统计"

# 样式设置
header_font = Font(bold=True, color='FFFFFF', size=12)
header_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
data_alignment = Alignment(horizontal='center', vertical='center')
thin_border = Border(
    left=Side(style='thin'),
    right=Side(style='thin'),
    top=Side(style='thin'),
    bottom=Side(style='thin')
)

# ============ 第一部分：按类别分类汇总 ============
print("\n=== 第一部分：按类别分类汇总 ===")

# 添加工作表 1 - 分类汇总
ws1 = wb.create_sheet(title="1.分类汇总")

# 选择数值列进行汇总
if numeric_cols:
    # 排除可能的 ID 列
    value_cols = [col for col in numeric_cols if col not in ['ID', 'id', '序号', '编号']]
else:
    value_cols = []

print(f"用于汇总的数值列：{value_cols}")

# 如果有分类列，按分类汇总
if category_col:
    # 分类汇总 - 计数
    count_summary = df.groupby(category_col).size().reset_index(name='计数')
    print(f"\n分类计数汇总:\n{count_summary}")

    # 分类汇总 - 求和
    if value_cols:
        sum_summary = df.groupby(category_col)[value_cols].sum().reset_index()
        print(f"\n分类求和汇总:\n{sum_summary}")

        # 分类汇总 - 平均值
        mean_summary = df.groupby(category_col)[value_cols].mean().reset_index()
        print(f"\n分类平均值汇总:\n{mean_summary}")

    # 将结果写入 Excel
    # 1. 计数汇总
    ws1['A1'] = '分类汇总 - 计数'
    ws1['A1'].font = Font(bold=True, size=14)
    for r in dataframe_to_rows(count_summary, index=False, header=True):
        ws1.append(r)

    # 添加求和汇总
    if value_cols:
        row_offset = len(count_summary) + 3
        ws1.cell(row=row_offset, column=1, value='分类汇总 - 求和').font = Font(bold=True, size=14)
        for r in dataframe_to_rows(sum_summary, index=False, header=True):
            ws1.append(r)

        # 添加平均值汇总
        row_offset = row_offset + len(sum_summary) + 2
        ws1.cell(row=row_offset, column=1, value='分类汇总 - 平均值').font = Font(bold=True, size=14)
        for r in dataframe_to_rows(mean_summary, index=False, header=True):
            ws1.append(r)

# ============ 第二部分：计算工作耗时 ============
print("\n=== 第二部分：计算工作耗时 ===")

ws2 = wb.create_sheet(title="2.工作耗时分析")

if std_time_col and volume_col:
    # 计算每项任务的工作耗时 = 标准工时 × 业务量
    df['工作耗时'] = df[std_time_col] * df[volume_col]
    print(f"工作耗时 = {std_time_col} × {volume_col}")
    print(f"工作耗时统计:\n{df['工作耗时'].describe()}")

    # 按 L3 分类汇总工作耗时
    if category_col:
        time_summary = df.groupby(category_col).agg({
            '工作耗时': 'sum',
            std_time_col: 'sum',
            volume_col: 'sum'
        }).reset_index()
        time_summary.columns = [category_col, '总工作耗时', '总标准工时', '总业务量']
        time_summary['耗时占比'] = time_summary['总工作耗时'] / time_summary['总工作耗时'].sum() * 100

        print(f"\n按 {category_col} 汇总工作耗时:\n{time_summary}")

        # 写入 Excel
        ws2['A1'] = f'按 {category_col} 汇总工作耗时'
        ws2['A1'].font = Font(bold=True, size=14)
        for r in dataframe_to_rows(time_summary, index=False, header=True):
            ws2.append(r)

        # 添加明细数据
        row_offset = len(time_summary) + 3
        ws2.cell(row=row_offset, column=1, value='明细数据（含工作耗时计算）').font = Font(bold=True, size=14)

        # 选择相关列
        detail_cols = [category_col, std_time_col, volume_col, '工作耗时']
        detail_cols = [col for col in detail_cols if col in df.columns]
        df_detail = df[detail_cols].copy()

        for r in dataframe_to_rows(df_detail.head(100), index=False, header=True):
            ws2.append(r)

# ============ 第三部分：添加图表 ============
print("\n=== 第三部分：添加图表 ===")

ws3 = wb.create_sheet(title="3.图表分析")

if category_col and std_time_col and volume_col:
    # 准备图表数据
    chart_data = df.groupby(category_col).agg({
        std_time_col: 'sum',
        volume_col: 'sum',
        '工作耗时': 'sum'
    }).reset_index()
    chart_data = chart_data.sort_values('工作耗时', ascending=False).head(10)  # 前 10 名

    # 写入图表数据
    ws3['A1'] = '各类别工作耗时对比（前 10 名）'
    ws3['A1'].font = Font(bold=True, size=14)

    headers = [category_col, '总标准工时', '总业务量', '总工作耗时']
    for col, header in enumerate(headers, 1):
        ws3.cell(row=2, column=col, value=header)
        ws3.cell(row=2, column=col).font = Font(bold=True)

    for i, row in chart_data.iterrows():
        ws3.cell(row=3+i, column=1, value=row[category_col])
        ws3.cell(row=3+i, column=2, value=row[std_time_col])
        ws3.cell(row=3+i, column=3, value=row[volume_col])
        ws3.cell(row=3+i, column=4, value=row['工作耗时'])

    # 添加柱状图
    chart = BarChart()
    chart.type = "col"
    chart.style = 10
    chart.title = "各类别工作耗时对比"
    chart.y_axis.title = '工作耗时'
    chart.x_axis.title = '分类'

    # 数据范围
    data = Reference(ws3, min_col=4, min_row=2, max_row=2+len(chart_data), max_col=4)
    cats = Reference(ws3, min_col=1, min_row=3, max_row=2+len(chart_data))

    chart.add_data(data, titles_from_data=True)
    chart.set_categories(cats)
    chart.shape = 4
    ws3.add_chart(chart, "F2")

    # 添加饼图 - 占比
    ws3.cell(row=15, column=1, value='各类别工作耗时占比')
    ws3.cell(row=15, column=1).font = Font(bold=True, size=14)

    pie = PieChart()
    pie.title = "工作耗时占比分布"

    data = Reference(ws3, min_col=4, min_row=3, max_row=2+len(chart_data), max_col=4)
    cats = Reference(ws3, min_col=1, min_row=3, max_row=2+len(chart_data))

    pie.add_data(data, titles_from_data=False)
    pie.set_categories(cats)
    ws3.add_chart(pie, "F15")

# 保存文件
print(f"\n=== 保存结果到：{output_file} ===")
wb.save(output_file)
print("完成！")
