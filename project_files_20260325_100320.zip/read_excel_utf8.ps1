# 使用 .NET 读取 Excel 文件
$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false
$excel.DisplayAlerts = $false

$workbook = $excel.Workbooks.Open("C:\Users\tangliying\lobsterai\project\survey.xlsx")
$worksheet = $workbook.Sheets.Item(1)

# 获取行数和列数
$rowCount = $worksheet.UsedRange.Rows.Count
$colCount = $worksheet.UsedRange.Columns.Count

$output = @()
$output += "总行数: $rowCount"
$output += "总列数: $colCount"

# 获取标题行
$output += ""
$output += "列名:"
for ($col = 1; $col -le $colCount; $col++) {
    $header = $worksheet.Cells.Item(1, $col).Text
    $output += "  $col. $header"
}

# 获取前3行数据示例
$output += ""
$output += "前3行数据:"
for ($row = 2; $row -le [Math]::Min(4, $rowCount); $row++) {
    $output += "  行 $($row-1):"
    for ($col = 1; $col -le $colCount; $col++) {
        $value = $worksheet.Cells.Item($row, $col).Text
        $header = $worksheet.Cells.Item(1, $col).Text
        $output += "    $header = $value"
    }
}

$workbook.Close()
$excel.Quit()

# 释放 COM 对象
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($worksheet) | Out-Null
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($workbook) | Out-Null
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($excel) | Out-Null

# 写入文件
$output | Out-File -FilePath "C:\Users\tangliying\lobsterai\project\excel_info.txt" -Encoding UTF8
Write-Host "Done"
