import subprocess
import pandas as pd

# 读取Excel文件
df = pd.read_excel('survey.xlsx')

# 生成报告内容
report = []
report.append("=" * 60)
report.append("📊 私域采访调研问卷分析报告")
report.append("=" * 60)
report.append("")

# 基本信息
report.append("【一、基本信息】")
report.append(f"  • 有效样本数: {len(df)} 份")
report.append(f"  • 问题数量: {len(df.columns)} 个")
report.append("")

# 问题列表
report.append("【二、问题列表】")
for i, col in enumerate(df.columns, 1):
    report.append(f"  {i}. {col}")
report.append("")

# 数据完整性
report.append("【三、数据完整性】")
report.append("-" * 40)
for col in df.columns:
    answered = df[col].notna().sum()
    rate = (answered / len(df)) * 100
    status = "✓" if rate >= 90 else "⚠" if rate >= 70 else "✗"
    report.append(f"  {status} {col}: {answered}/{len(df)} ({rate:.1f}%)")
report.append("")

# 各问题详细分析
report.append("【四、各问题回答分布】")
report.append("=" * 60)

for idx, col in enumerate(df.columns, 1):
    report.append(f"")
    report.append(f"▶ 问题 {idx}: {col}")
    report.append("-" * 40)
    
    unique_count = df[col].nunique()
    report.append(f"  不同回答数: {unique_count}")
    
    if pd.api.types.is_numeric_dtype(df[col]):
        report.append(f"  平均值: {df[col].mean():.2f}")
        report.append(f"  中位数: {df[col].median():.2f}")
        report.append(f"  最小值: {df[col].min()}")
        report.append(f"  最大值: {df[col].max()}")
    
    report.append(f"  回答分布:")
    value_counts = df[col].value_counts().head(10)
    total = len(df)
    for val, count in value_counts.items():
        pct = (count / total) * 100
        bar = "█" * int(pct / 5)
        display_val = str(val)[:40] if len(str(val)) > 40 else str(val)
        report.append(f"    • {display_val}: {count} ({pct:.1f}%) {bar}")
    
    if unique_count > 10:
        report.append(f"    ... 还有 {unique_count - 10} 个其他回答")

report.append("")
report.append("=" * 60)
report.append("分析完成")
report.append("=" * 60)

# 写入文件
with open('survey_report.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(report))

print("报告已生成")
