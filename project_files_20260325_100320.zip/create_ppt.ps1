# 创建自我介绍 PPT - 简约商务风格
# 使用 PowerPoint COM 对象

$ErrorActionPreference = "Stop"
$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

try {
    # 创建 PowerPoint 应用对象
    $powerPoint = New-Object -ComObject PowerPoint.Application
    $powerPoint.Visible = [Microsoft.Office.Core.MsoTriState]::msoFalse

    # 创建新的演示文稿
    $presentation = $powerPoint.Presentations.Add()

    # 设置宽屏 16:9
    $presentation.PageSetup.SlideWidth = 960
    $presentation.PageSetup.SlideHeight = 540

    Write-Host "Starting PPT creation..."

    # 添加标题页
    Write-Host "Creating cover slide..."
    $slide1 = $presentation.Slides.Add(1, 12)  # ppLayoutBlank

    # 添加蓝色背景
    $bg = $slide1.Shapes.AddShape(1, 0, 0, 960, 540)  # msoShapeRectangle
    $bg.Fill.ForeColor.RGB = [RGB]::FromArgb(30, 58, 138)  # Dark blue
    $bg.Line.Visible = 0  # msoFalse

    # 添加标题
    $title = $slide1.Shapes.AddTextbox(1, 50, 150, 860, 100)
    $title.TextFrame.TextRange.Text = "自我介绍"
    $title.TextFrame.TextRange.Font.Size = 54
    $title.TextFrame.TextRange.Font.Bold = 1
    $title.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(255, 255, 255)
    $title.TextFrame.TextRange.ParagraphFormat.Alignment = 2  # ppAlignCenter

    # 添加副标题
    $subtitle = $slide1.Shapes.AddTextbox(1, 50, 250, 860, 80)
    $subtitle.TextFrame.TextRange.Text = "Personal Introduction"
    $subtitle.TextFrame.TextRange.Font.Size = 28
    $subtitle.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(219, 234, 254)
    $subtitle.TextFrame.TextRange.ParagraphFormat.Alignment = 2

    # 添加个人概况页
    Write-Host "Creating profile slide..."
    $slide2 = $presentation.Slides.Add(2, 12)

    $header = $slide2.Shapes.AddShape(1, 0, 0, 960, 70)
    $header.Fill.ForeColor.RGB = [RGB]::FromArgb(30, 58, 138)
    $header.Line.Visible = 0

    $title2 = $slide2.Shapes.AddTextbox(1, 40, 15, 400, 50)
    $title2.TextFrame.TextRange.Text = "个人概况"
    $title2.TextFrame.TextRange.Font.Size = 32
    $title2.TextFrame.TextRange.Font.Bold = 1
    $title2.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(255, 255, 255)

    $content2 = $slide2.Shapes.AddTextbox(1, 40, 90, 880, 400)
    $content2.TextFrame.TextRange.Text = "姓名：[您的姓名]`r`n联系电话：[您的电话号码]`r`n电子邮箱：[您的邮箱地址]`r`n所在城市：[您所在的城市]`r`n`r`n个人标签：`r`n  - 积极进取 | 团队协作 | 创新思维`r`n  - 学习能力强 | 责任心强 | 执行力高`r`n`r`n自我介绍：`r`n  简洁有力的个人简介，突出核心优势和职业特点..."
    $content2.TextFrame.TextRange.Font.Size = 18
    $content2.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(55, 65, 81)

    # 添加教育背景页
    Write-Host "Creating education slide..."
    $slide3 = $presentation.Slides.Add(3, 12)

    $header3 = $slide3.Shapes.AddShape(1, 0, 0, 960, 70)
    $header3.Fill.ForeColor.RGB = [RGB]::FromArgb(30, 58, 138)
    $header3.Line.Visible = 0

    $title3 = $slide3.Shapes.AddTextbox(1, 40, 15, 400, 50)
    $title3.TextFrame.TextRange.Text = "教育背景"
    $title3.TextFrame.TextRange.Font.Size = 32
    $title3.TextFrame.TextRange.Font.Bold = 1
    $title3.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(255, 255, 255)

    $content3 = $slide3.Shapes.AddTextbox(1, 40, 90, 880, 400)
    $content3.TextFrame.TextRange.Text = "[最高学历] | [学校名称] | [专业名称] | [入学年份]-[毕业年份]`r`n  主修课程：[核心课程列表]`r`n  GPA：[如果优秀可填写]`r`n`r`n[本科学历] | [学校名称] | [专业名称] | [入学年份]-[毕业年份]`r`n  主修课程：[核心课程列表]`r`n`r`n校园荣誉：`r`n  - [奖学金/荣誉称号等]`r`n  - [校园活动/社团经历]"
    $content3.TextFrame.TextRange.Font.Size = 18
    $content3.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(55, 65, 81)

    # 添加工作经历页
    Write-Host "Creating work experience slide..."
    $slide4 = $presentation.Slides.Add(4, 12)

    $header4 = $slide4.Shapes.AddShape(1, 0, 0, 960, 70)
    $header4.Fill.ForeColor.RGB = [RGB]::FromArgb(30, 58, 138)
    $header4.Line.Visible = 0

    $title4 = $slide4.Shapes.AddTextbox(1, 40, 15, 400, 50)
    $title4.TextFrame.TextRange.Text = "工作经历"
    $title4.TextFrame.TextRange.Font.Size = 32
    $title4.TextFrame.TextRange.Font.Bold = 1
    $title4.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(255, 255, 255)

    $content4 = $slide4.Shapes.AddTextbox(1, 40, 90, 880, 400)
    $content4.TextFrame.TextRange.Text = "[最近公司] | [职位名称] | [入职时间]-[至今/离职时间]`r`n  - 主要职责：[工作职责描述]`r`n  - 核心成就：[工作成果]`r`n`r`n[前公司] | [职位名称] | [入职时间]-[离职时间]`r`n  - 主要职责：[工作职责描述]`r`n  - 核心成就：[工作成果]`r`n`r`n[更早公司] | [职位名称] | [入职时间]-[离职时间]`r`n  - 主要职责：[工作职责描述]"
    $content4.TextFrame.TextRange.Font.Size = 18
    $content4.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(55, 65, 81)

    # 添加项目经验页
    Write-Host "Creating project experience slide..."
    $slide5 = $presentation.Slides.Add(5, 12)

    $header5 = $slide5.Shapes.AddShape(1, 0, 0, 960, 70)
    $header5.Fill.ForeColor.RGB = [RGB]::FromArgb(30, 58, 138)
    $header5.Line.Visible = 0

    $title5 = $slide5.Shapes.AddTextbox(1, 40, 15, 400, 50)
    $title5.TextFrame.TextRange.Text = "项目经验"
    $title5.TextFrame.TextRange.Font.Size = 32
    $title5.TextFrame.TextRange.Font.Bold = 1
    $title5.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(255, 255, 255)

    # 添加项目卡片
    $cardWidth = 420
    $cardHeight = 150
    $gap = 30

    $project1 = $slide5.Shapes.AddShape(7, 40, 90, $cardWidth, $cardHeight)
    $project1.Fill.ForeColor.RGB = [RGB]::FromArgb(219, 234, 254)
    $project1.Line.Visible = 0
    $project1.TextFrame.TextRange.Text = "[项目名称 1]`r`n角色：[项目角色]`r`n成果：[项目成果/数据]"
    $project1.TextFrame.TextRange.Font.Size = 16
    $project1.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(55, 65, 81)

    $project2 = $slide5.Shapes.AddShape(7, 490, 90, $cardWidth, $cardHeight)
    $project2.Fill.ForeColor.RGB = [RGB]::FromArgb(219, 234, 254)
    $project2.Line.Visible = 0
    $project2.TextFrame.TextRange.Text = "[项目名称 2]`r`n角色：[项目角色]`r`n成果：[项目成果/数据]"
    $project2.TextFrame.TextRange.Font.Size = 16
    $project2.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(55, 65, 81)

    $project3 = $slide5.Shapes.AddShape(7, 40, 270, $cardWidth, $cardHeight)
    $project3.Fill.ForeColor.RGB = [RGB]::FromArgb(219, 234, 254)
    $project3.Line.Visible = 0
    $project3.TextFrame.TextRange.Text = "[项目名称 3]`r`n角色：[项目角色]`r`n成果：[项目成果/数据]"
    $project3.TextFrame.TextRange.Font.Size = 16
    $project3.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(55, 65, 81)

    $project4 = $slide5.Shapes.AddShape(7, 490, 270, $cardWidth, $cardHeight)
    $project4.Fill.ForeColor.RGB = [RGB]::FromArgb(219, 234, 254)
    $project4.Line.Visible = 0
    $project4.TextFrame.TextRange.Text = "[项目名称 4]`r`n角色：[项目角色]`r`n成果：[项目成果/数据]"
    $project4.TextFrame.TextRange.Font.Size = 16
    $project4.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(55, 65, 81)

    # 添加专业技能页
    Write-Host "Creating skills slide..."
    $slide6 = $presentation.Slides.Add(6, 12)

    $header6 = $slide6.Shapes.AddShape(1, 0, 0, 960, 70)
    $header6.Fill.ForeColor.RGB = [RGB]::FromArgb(30, 58, 138)
    $header6.Line.Visible = 0

    $title6 = $slide6.Shapes.AddTextbox(1, 40, 15, 400, 50)
    $title6.TextFrame.TextRange.Text = "专业技能"
    $title6.TextFrame.TextRange.Font.Size = 32
    $title6.TextFrame.TextRange.Font.Bold = 1
    $title6.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(255, 255, 255)

    $skillNames = @("专业技能 1", "专业技能 2", "专业技能 3", "专业技能 4", "语言/工具", "软技能")
    $skillLevels = @(90, 85, 80, 75, 85, 90)

    $startY = 90
    $itemHeight = 50

    for ($i = 0; $i -lt 6; $i++) {
        $y = $startY + $i * $itemHeight

        $skillName = $slide6.Shapes.AddTextbox(1, 40, $y, 200, 40)
        $skillName.TextFrame.TextRange.Text = $skillNames[$i]
        $skillName.TextFrame.TextRange.Font.Size = 16
        $skillName.TextFrame.TextRange.Font.Bold = 1
        $skillName.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(55, 65, 81)

        $barBg = $slide6.Shapes.AddShape(1, 250, $y + 10, 500, 20)
        $barBg.Fill.ForeColor.RGB = [RGB]::FromArgb(243, 244, 246)
        $barBg.Line.Visible = 0

        $barWidth = 500 * $skillLevels[$i] / 100
        $bar = $slide6.Shapes.AddShape(1, 250, $y + 10, $barWidth, 20)
        $bar.Fill.ForeColor.RGB = [RGB]::FromArgb(59, 130, 246)
        $bar.Line.Visible = 0

        $percent = $slide6.Shapes.AddTextbox(1, 760, $y, 100, 40)
        $percent.TextFrame.TextRange.Text = "$($skillLevels[$i])%"
        $percent.TextFrame.TextRange.Font.Size = 14
        $percent.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(107, 114, 128)
    }

    # 添加荣誉证书页
    Write-Host "Creating certificates slide..."
    $slide7 = $presentation.Slides.Add(7, 12)

    $header7 = $slide7.Shapes.AddShape(1, 0, 0, 960, 70)
    $header7.Fill.ForeColor.RGB = [RGB]::FromArgb(30, 58, 138)
    $header7.Line.Visible = 0

    $title7 = $slide7.Shapes.AddTextbox(1, 40, 15, 400, 50)
    $title7.TextFrame.TextRange.Text = "荣誉证书"
    $title7.TextFrame.TextRange.Font.Size = 32
    $title7.TextFrame.TextRange.Font.Bold = 1
    $title7.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(255, 255, 255)

    $content7 = $slide7.Shapes.AddTextbox(1, 40, 90, 880, 400)
    $content7.TextFrame.TextRange.Text = "专业认证：`r`n  - [证书名称 1] | [颁发机构] | [获得时间]`r`n  - [证书名称 2] | [颁发机构] | [获得时间]`r`n  - [证书名称 3] | [颁发机构] | [获得时间]`r`n`r`n荣誉奖项：`r`n  - [奖项名称 1] | [颁发单位] | [获得时间]`r`n  - [奖项名称 2] | [颁发单位] | [获得时间]`r`n`r`n其他资质：`r`n  - [资质证书/语言能力等]"
    $content7.TextFrame.TextRange.Font.Size = 18
    $content7.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(55, 65, 81)

    # 添加兴趣爱好页
    Write-Host "Creating hobbies slide..."
    $slide8 = $presentation.Slides.Add(8, 12)

    $header8 = $slide8.Shapes.AddShape(1, 0, 0, 960, 70)
    $header8.Fill.ForeColor.RGB = [RGB]::FromArgb(30, 58, 138)
    $header8.Line.Visible = 0

    $title8 = $slide8.Shapes.AddTextbox(1, 40, 15, 400, 50)
    $title8.TextFrame.TextRange.Text = "兴趣爱好"
    $title8.TextFrame.TextRange.Font.Size = 32
    $title8.TextFrame.TextRange.Font.Bold = 1
    $title8.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(255, 255, 255)

    $content8 = $slide8.Shapes.AddTextbox(1, 40, 90, 880, 400)
    $content8.TextFrame.TextRange.Text = "运动健身：`r`n  - [运动项目] - 保持健康体魄，培养毅力`r`n`r`n阅读学习：`r`n  - [书籍类型] - 持续学习，拓展知识面`r`n`r`n艺术爱好：`r`n  - [艺术项目] - 培养审美，提升创造力`r`n`r`n社会实践：`r`n  - [志愿活动/社团] - 回馈社会，锻炼能力`r`n`r`n个人特长：`r`n  - [特殊技能/才能]"
    $content8.TextFrame.TextRange.Font.Size = 18
    $content8.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(55, 65, 81)

    # 添加未来规划页
    Write-Host "Creating future plans slide..."
    $slide9 = $presentation.Slides.Add(9, 12)

    $header9 = $slide9.Shapes.AddShape(1, 0, 0, 960, 70)
    $header9.Fill.ForeColor.RGB = [RGB]::FromArgb(30, 58, 138)
    $header9.Line.Visible = 0

    $title9 = $slide9.Shapes.AddTextbox(1, 40, 15, 400, 50)
    $title9.TextFrame.TextRange.Text = "未来规划"
    $title9.TextFrame.TextRange.Font.Size = 32
    $title9.TextFrame.TextRange.Font.Bold = 1
    $title9.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(255, 255, 255)

    $content9 = $slide9.Shapes.AddTextbox(1, 40, 90, 880, 400)
    $content9.TextFrame.TextRange.Text = "短期目标 (1-2 年)：`r`n  - [具体目标 1] - 提升专业技能`r`n  - [具体目标 2] - 积累项目经验`r`n  - [具体目标 3] - 拓展行业视野`r`n`r`n中期目标 (3-5 年)：`r`n  - [发展方向] - 成为领域专家`r`n  - [能力提升] - 提升管理能力`r`n`r`n长期愿景：`r`n  - [职业愿景] - 实现职业理想`r`n  - [个人价值] - 创造更大价值"
    $content9.TextFrame.TextRange.Font.Size = 18
    $content9.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(55, 65, 81)

    # 添加结束页
    Write-Host "Creating ending slide..."
    $slide10 = $presentation.Slides.Add(10, 12)

    $bg10 = $slide10.Shapes.AddShape(1, 0, 0, 960, 540)
    $bg10.Fill.ForeColor.RGB = [RGB]::FromArgb(30, 58, 138)
    $bg10.Line.Visible = 0

    $thanks = $slide10.Shapes.AddTextbox(1, 50, 180, 860, 100)
    $thanks.TextFrame.TextRange.Text = "感谢聆听"
    $thanks.TextFrame.TextRange.Font.Size = 48
    $thanks.TextFrame.TextRange.Font.Bold = 1
    $thanks.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(255, 255, 255)
    $thanks.TextFrame.TextRange.ParagraphFormat.Alignment = 2

    $contact = $slide10.Shapes.AddTextbox(1, 50, 280, 860, 80)
    $contact.TextFrame.TextRange.Text = "联系方式：[电话] | [邮箱]`r`nTHANK YOU"
    $contact.TextFrame.TextRange.Font.Size = 24
    $contact.TextFrame.TextRange.Font.Color.RGB = [RGB]::FromArgb(219, 234, 254)
    $contact.TextFrame.TextRange.ParagraphFormat.Alignment = 2

    # 保存文件
    $outputPath = "C:\Users\tangliying\lobsterai\project\self_introduction.pptx"
    $presentation.SaveAs($outputPath, 24)  # ppSaveAsOpenXMLPresentation = 24
    Write-Host "PPT created successfully! Path: $outputPath"

    # 关闭 PowerPoint
    $presentation.Close()
    $powerPoint.Quit()

    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($powerPoint) | Out-Null
    Write-Host "Done!"

} catch {
    Write-Host "Error: $_"
    Write-Host $_.ScriptStackTrace
}
