# -*- coding: utf-8 -*-
"""
Excel 数据分类汇总分析脚本
列名：分类 2L3、统计单位、标准工时、业务量、业务耗时、耗时占比
"""

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.chart import BarChart, Reference, PieChart
from openpyxl.utils.dataframe import dataframe_to_rows
import numpy as np

# 文件路径
input_file = r'C:\Users\tangliying\lobsterai\project\AI 测试数据.xlsx'
output_file = r'C:\Users\tangliying\lobsterai\project\汇总统计结果.xlsx'

print("=== 开始读取数据 ===")

# 读取 Excel 文件
df = pd.read_excel(input_file)
print(f"数据形状：{df.shape}")
print(f"列名：{df.columns.tolist()}")
print(f"\n前 5 行数据:\n{df.head()}")

# 定义列名
category_col = '分类 2L3'
std_time_col = '标准工时'
volume_col = '业务量'
time_col = '业务耗时'
ratio_col = '耗时占比'

# 创建输出 Excel 文件
wb = Workbook()
ws = wb.active
ws.title = "汇总统计"

# 样式设置
header_font = Font(bold=True, color='FFFFFF', size=12)
header_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
title_font = Font(bold=True, size=14)
thin_border = Border(
    left=Side(style='thin'),
    right=Side(style='thin'),
    top=Side(style='thin'),
    bottom=Side(style='thin')
)

def apply_header_style(cell):
    cell.font = Font(bold=True, color='FFFFFF', size=11)
    cell.fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
    cell.alignment = Alignment(horizontal='center', vertical='center')
    cell.border = thin_border

def apply_data_style(cell):
    cell.alignment = Alignment(horizontal='center', vertical='center')
    cell.border = thin_border

# ============ 第一部分：按类别分类汇总 ============
print("\n=== 1. 按类别分类汇总 ===")

ws1 = wb.create_sheet(title="1.分类汇总")

# 1.1 计数汇总
count_df = df.groupby(category_col).size().reset_index(name='计数')
count_df = count_df.sort_values('计数', ascending=False)
print(f"分类计数:\n{count_df}")

# 写入计数汇总
start_row = 2
ws1.cell(row=1, column=1, value='【分类汇总 - 计数】').font = title_font
headers = ['序号', category_col, '计数']
for c, h in enumerate(headers):
    cell = ws1.cell(row=start_row, column=c+1, value=h)
    apply_header_style(cell)

for i, (_, row) in enumerate(count_df.iterrows()):
    ws1.cell(row=start_row+1+i, column=1, value=i+1)
    ws1.cell(row=start_row+1+i, column=2, value=row[category_col])
    ws1.cell(row=start_row+1+i, column=3, value=row['计数'])
    for c in range(1, 4):
        apply_data_style(ws1.cell(row=start_row+1+i, column=c))

# 1.2 求和汇总
sum_cols = [std_time_col, volume_col, time_col]
sum_df = df.groupby(category_col)[sum_cols].sum().reset_index()
sum_df = sum_df.sort_values(time_col, ascending=False)
print(f"\n分类求和:\n{sum_df}")

# 写入求和汇总
row_off = start_row + len(count_df) + 3
ws1.cell(row=row_off, column=1, value='【分类汇总 - 求和】').font = title_font
headers = ['序号', category_col, std_time_col, volume_col, time_col]
for c, h in enumerate(headers):
    cell = ws1.cell(row=row_off+1, column=c+1, value=h)
    apply_header_style(cell)

for i, (_, row) in enumerate(sum_df.iterrows()):
    ws1.cell(row=row_off+2+i, column=1, value=i+1)
    ws1.cell(row=row_off+2+i, column=2, value=row[category_col])
    ws1.cell(row=row_off+2+i, column=3, value=row[std_time_col])
    ws1.cell(row=row_off+2+i, column=4, value=row[volume_col])
    ws1.cell(row=row_off+2+i, column=5, value=row[time_col])
    for c in range(1, 6):
        apply_data_style(ws1.cell(row=row_off+2+i, column=c))

# 1.3 平均值汇总
mean_df = df.groupby(category_col)[sum_cols].mean().reset_index()
mean_df = mean_df.sort_values(time_col, ascending=False)
print(f"\n分类平均值:\n{mean_df}")

# 写入平均值汇总
row_off = row_off + len(sum_df) + 3
ws1.cell(row=row_off, column=1, value='【分类汇总 - 平均值】').font = title_font
headers = ['序号', category_col, f'{std_time_col}(平均)', f'{volume_col}(平均)', f'{time_col}(平均)']
for c, h in enumerate(headers):
    cell = ws1.cell(row=row_off+1, column=c+1, value=h)
    apply_header_style(cell)

for i, (_, row) in enumerate(mean_df.iterrows()):
    ws1.cell(row=row_off+2+i, column=1, value=i+1)
    ws1.cell(row=row_off+2+i, column=2, value=row[category_col])
    ws1.cell(row=row_off+2+i, column=3, value=round(row[std_time_col], 2))
    ws1.cell(row=row_off+2+i, column=4, value=round(row[volume_col], 2))
    ws1.cell(row=row_off+2+i, column=5, value=round(row[time_col], 2))
    for c in range(1, 6):
        apply_data_style(ws1.cell(row=row_off+2+i, column=c))

# ============ 第二部分：工作耗时分析 ============
print("\n=== 2. 工作耗时分析 ===")

ws2 = wb.create_sheet(title="2.工作耗时分析")

# 计算工作耗时（如果有标准工时和业务量）
if std_time_col in df.columns and volume_col in df.columns:
    # 计算工作耗时 = 标准工时 × 业务量
    df['计算耗时'] = df[std_time_col] * df[volume_col]
    print(f"计算耗时 = {std_time_col} × {volume_col}")

# 按 L3 分类汇总
time_df = df.groupby(category_col).agg({
    std_time_col: 'sum',
    volume_col: 'sum',
    time_col: 'sum' if time_col in df.columns else 'first'
}).reset_index()

if time_col in df.columns:
    time_df.columns = [category_col, '总标准工时', '总业务量', '总业务耗时']
    # 计算占比
    total_time = time_df['总业务耗时'].sum()
    time_df['耗时占比 (%)'] = (time_df['总业务耗时'] / total_time * 100).round(2)
else:
    time_df.columns = [category_col, '总标准工时', '总业务量']
    time_df['总业务耗时'] = time_df['总标准工时'] * time_df['总业务量']
    total_time = time_df['总业务耗时'].sum()
    time_df['耗时占比 (%)'] = (time_df['总业务耗时'] / total_time * 100).round(2)

time_df = time_df.sort_values('总业务耗时', ascending=False)
print(f"\n按 {category_col} 汇总:\n{time_df}")

# 写入工作耗时汇总
start_row = 2
ws2.cell(row=1, column=1, value=f'【按 {category_col} 汇总工作耗时】').font = title_font
headers = ['序号', category_col, '总标准工时', '总业务量', '总业务耗时', '耗时占比 (%)']
for c, h in enumerate(headers):
    cell = ws2.cell(row=start_row, column=c+1, value=h)
    apply_header_style(cell)

for i, (_, row) in enumerate(time_df.iterrows()):
    ws2.cell(row=start_row+1+i, column=1, value=i+1)
    ws2.cell(row=start_row+1+i, column=2, value=row[category_col])
    ws2.cell(row=start_row+1+i, column=3, value=row['总标准工时'])
    ws2.cell(row=start_row+1+i, column=4, value=row['总业务量'])
    ws2.cell(row=start_row+1+i, column=5, value=row['总业务耗时'])
    ws2.cell(row=start_row+1+i, column=6, value=row['耗时占比 (%)'])
    for c in range(1, 7):
        apply_data_style(ws2.cell(row=start_row+1+i, column=c))

# 添加明细数据
row_off = start_row + len(time_df) + 3
ws2.cell(row=row_off, column=1, value='【明细数据】').font = title_font

detail_cols = [category_col, std_time_col, volume_col]
if time_col in df.columns:
    detail_cols.append(time_col)
if '计算耗时' in df.columns:
    detail_cols.append('计算耗时')

for c, col in enumerate(detail_cols):
    ws2.cell(row=row_off+1, column=c+1, value=col).font = Font(bold=True)

for i, (_, row) in enumerate(df[detail_cols].iterrows()):
    for j, val in enumerate(row.values):
        ws2.cell(row=row_off+2+i, column=j+1, value=val)

# ============ 第三部分：图表分析 ============
print("\n=== 3. 图表分析 ===")

ws3 = wb.create_sheet(title="3.图表分析")

# 前 10 名数据用于图表
chart_df = time_df.head(10)

# 写入图表数据
ws3.cell(row=1, column=1, value='【各类别工作耗时对比（前 10 名）】').font = title_font
headers = ['序号', category_col, '总标准工时', '总业务量', '总业务耗时']
for c, h in enumerate(headers):
    cell = ws3.cell(row=2, column=c+1, value=h)
    apply_header_style(cell)

for i, (_, row) in enumerate(chart_df.iterrows()):
    ws3.cell(row=3+i, column=1, value=i+1)
    ws3.cell(row=3+i, column=2, value=row[category_col])
    ws3.cell(row=3+i, column=3, value=row['总标准工时'])
    ws3.cell(row=3+i, column=4, value=row['总业务量'])
    ws3.cell(row=3+i, column=5, value=row['总业务耗时'])

# 添加柱状图
chart = BarChart()
chart.title = "各类别工作耗时对比"
chart.y_axis.title = '业务耗时'
chart.x_axis.title = '分类'
chart.style = 10

data = Reference(ws3, min_col=5, min_row=2, max_row=2+len(chart_df))
cats = Reference(ws3, min_col=2, min_row=3, max_row=2+len(chart_df))

chart.add_data(data, titles_from_data=True)
chart.set_categories(cats)
chart.shape = 4
ws3.add_chart(chart, "G2")

# 添加饼图 - 占比
ws3.cell(row=15, column=1, value='【工作耗时占比分布】').font = title_font

pie = PieChart()
pie.title = "耗时占比"

data = Reference(ws3, min_col=5, min_row=3, max_row=2+len(chart_df))
cats = Reference(ws3, min_col=2, min_row=3, max_row=2+len(chart_df))

pie.add_data(data, titles_from_data=False)
pie.set_categories(cats)
pie.height = 5
pie.width = 8
ws3.add_chart(pie, "G15")

# 添加占比表格
row_off = 15 + len(chart_df)
ws3.cell(row=row_off, column=1, value='【占比分析】').font = title_font
headers = ['分类', '耗时占比', '排名']
for c, h in enumerate(headers):
    cell = ws3.cell(row=row_off+1, column=c+1, value=h)
    apply_header_style(cell)

sorted_df = time_df.sort_values('耗时占比 (%)', ascending=False)
for i, (_, row) in enumerate(sorted_df.iterrows()):
    ws3.cell(row=row_off+2+i, column=1, value=row[category_col])
    ws3.cell(row=row_off+2+i, column=2, value=f"{row['耗时占比 (%)']}%")
    ws3.cell(row=row_off+2+i, column=3, value=i+1)

# 保存文件
print(f"\n=== 保存结果 ===")
wb.save(output_file)
print(f"完成！结果已保存到：{output_file}")

# 统计信息
print("\n=== 统计摘要 ===")
print(f"总记录数：{len(df)}")
print(f"分类数量：{df[category_col].nunique()}")
print(f"总标准工时：{df[std_time_col].sum()}")
print(f"总业务量：{df[volume_col].sum()}")
if time_col in df.columns:
    print(f"总业务耗时：{df[time_col].sum()}")
